'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Eye, EyeOff, UserPlus, User, Mail, Phone, ArrowRight, Check, Lock, Building, Shield, Clock, Users } from 'lucide-react'

export default function InscriptionPage() {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    company: '',
    companySize: '',
    password: '',
    confirmPassword: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [acceptedTerms, setAcceptedTerms] = useState(false)

  const passwordStrength = () => {
    const pwd = formData.password
    if (pwd.length < 8) return { level: 'Faible', color: 'text-red-500', width: '33%' }
    if (pwd.length < 12 || !/[A-Z]/.test(pwd) || !/[0-9]/.test(pwd)) return { level: 'Moyen', color: 'text-yellow-500', width: '66%' }
    return { level: 'Fort', color: 'text-green-500', width: '100%' }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (step === 1) {
      setStep(2)
      return
    }
    if (formData.password !== formData.confirmPassword) {
      alert('Les mots de passe ne correspondent pas')
      return
    }
    if (!acceptedTerms) {
      alert('Veuillez accepter les conditions d\'utilisation')
      return
    }
    setIsLoading(true)
    setTimeout(() => {
      setIsLoading(false)
      alert('Inscription réussie ! Vérifiez votre email pour activer votre compte.')
    }, 1500)
  }

  return (
    <main className="min-h-screen bg-white flex">
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:flex-1 bg-gradient-to-br from-[#0A0A8A] via-[#0A0A8A] to-[#050560] relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 right-20 w-72 h-72 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-20 left-20 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 flex flex-col justify-center px-16 xl:px-24 text-white">
          {/* Main Content */}
          <div className="mb-12">
            <h2 className="text-4xl xl:text-5xl font-bold mb-6 leading-tight">
              Commencez votre<br />
              <span className="text-blue-300">transformation maintenance</span>
            </h2>
            <p className="text-lg text-white/70 leading-relaxed">
              Essai gratuit de 30 jours. Sans engagement. Formation et support inclus.
            </p>
          </div>

          {/* Benefits */}
          <div className="space-y-4 mb-12">
            <div className="flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
              <Check className="w-5 h-5 text-green-400" />
              <span className="text-white/90">Essai gratuit 30 jours, sans carte bancaire</span>
            </div>
            <div className="flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
              <Check className="w-5 h-5 text-green-400" />
              <span className="text-white/90">Formation personnalisée incluse</span>
            </div>
            <div className="flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
              <Check className="w-5 h-5 text-green-400" />
              <span className="text-white/90">Support technique réactif</span>
            </div>
            <div className="flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
              <Check className="w-5 h-5 text-green-400" />
              <span className="text-white/90">Données hébergées en France (RGPD)</span>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold">350+</div>
              <div className="text-sm text-white/60">Clients</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">-30%</div>
              <div className="text-sm text-white/60">Temps d&apos;arrêt</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">25</div>
              <div className="text-sm text-white/60">Pays</div>
            </div>
          </div>

          {/* Trust Badge */}
          <div className="mt-12 pt-8 border-t border-white/20">
            <div className="flex items-center gap-3">
              <img
                src="/upload/logo-bbc.png"
                alt="BBC & Partners"
                className="h-12 brightness-0 invert opacity-80"
              />
              <div>
                <div className="text-sm font-medium text-white">Développé par BBC & Partners</div>
                <div className="text-xs text-white/50">Depuis 2009</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="flex-1 flex flex-col justify-center px-8 lg:px-16 xl:px-24 py-12">
        <div className="max-w-md w-full mx-auto">
          {/* Logo */}
          <Link href="/" className="inline-block mb-8">
            <img
              src="/upload/logo-maintex.png"
              alt="MAINTEX"
              className="h-10"
            />
          </Link>

          {/* Progress */}
          <div className="flex items-center gap-3 mb-8">
            <div className={`flex items-center gap-2 ${step >= 1 ? 'text-[#0A0A8A]' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${step >= 1 ? 'bg-[#0A0A8A] text-white' : 'bg-gray-100 text-gray-400'}`}>
                {step > 1 ? <Check className="w-4 h-4" /> : '1'}
              </div>
              <span className="text-sm font-medium hidden sm:inline">Informations</span>
            </div>
            <div className={`flex-1 h-0.5 ${step >= 2 ? 'bg-[#0A0A8A]' : 'bg-gray-200'}`} />
            <div className={`flex items-center gap-2 ${step >= 2 ? 'text-[#0A0A8A]' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${step >= 2 ? 'bg-[#0A0A8A] text-white' : 'bg-gray-100 text-gray-400'}`}>
                2
              </div>
              <span className="text-sm font-medium hidden sm:inline">Compte</span>
            </div>
          </div>

          {/* Title */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              {step === 1 ? 'Créer votre compte' : 'Finaliser votre inscription'}
            </h1>
            <p className="text-gray-500">
              {step === 1 ? 'Commencez votre essai gratuit de 30 jours' : 'Sécurisez votre compte'}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {step === 1 ? (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-2">
                      Prénom
                    </label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                        required
                        className="w-full pl-12 pr-4 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0A0A8A] focus:border-transparent outline-none transition-all text-gray-900 bg-gray-50 focus:bg-white"
                        placeholder="Jean"
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-2">
                      Nom
                    </label>
                    <input
                      type="text"
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                      required
                      className="w-full px-4 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0A0A8A] focus:border-transparent outline-none transition-all text-gray-900 bg-gray-50 focus:bg-white"
                      placeholder="Dupont"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Adresse email professionnelle
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      id="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      required
                      className="w-full pl-12 pr-4 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0A0A8A] focus:border-transparent outline-none transition-all text-gray-900 bg-gray-50 focus:bg-white"
                      placeholder="jean.dupont@entreprise.com"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                    Numéro de téléphone
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="tel"
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="w-full pl-12 pr-4 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0A0A8A] focus:border-transparent outline-none transition-all text-gray-900 bg-gray-50 focus:bg-white"
                      placeholder="+33 6 12 34 56 78"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-2">
                    Entreprise
                  </label>
                  <div className="relative">
                    <Building className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      id="company"
                      value={formData.company}
                      onChange={(e) => setFormData({...formData, company: e.target.value})}
                      required
                      className="w-full pl-12 pr-4 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0A0A8A] focus:border-transparent outline-none transition-all text-gray-900 bg-gray-50 focus:bg-white"
                      placeholder="Nom de votre entreprise"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="companySize" className="block text-sm font-medium text-gray-700 mb-2">
                    Taille de l&apos;équipe maintenance
                  </label>
                  <select
                    id="companySize"
                    value={formData.companySize}
                    onChange={(e) => setFormData({...formData, companySize: e.target.value})}
                    required
                    className="w-full px-4 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0A0A8A] focus:border-transparent outline-none transition-all text-gray-900 bg-gray-50 focus:bg-white"
                  >
                    <option value="">Sélectionnez...</option>
                    <option value="1-5">1-5 techniciens</option>
                    <option value="6-20">6-20 techniciens</option>
                    <option value="21-50">21-50 techniciens</option>
                    <option value="51-100">51-100 techniciens</option>
                    <option value="100+">Plus de 100 techniciens</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 px-6 bg-[#0A0A8A] text-white font-semibold rounded-xl hover:bg-[#0A0A8A]/90 transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#0A0A8A]/20"
                >
                  Continuer
                  <ArrowRight className="w-5 h-5" />
                </button>
              </>
            ) : (
              <>
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                    Mot de passe
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      id="password"
                      value={formData.password}
                      onChange={(e) => setFormData({...formData, password: e.target.value})}
                      required
                      minLength={8}
                      className="w-full pl-12 pr-12 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0A0A8A] focus:border-transparent outline-none transition-all text-gray-900 bg-gray-50 focus:bg-white"
                      placeholder="Minimum 8 caractères"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  {formData.password && (
                    <div className="mt-2 flex items-center gap-2">
                      <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className={`h-full transition-all ${
                            passwordStrength().width === '33%' ? 'bg-red-500' :
                            passwordStrength().width === '66%' ? 'bg-yellow-500' : 'bg-green-500'
                          }`}
                          style={{ width: passwordStrength().width }}
                        />
                      </div>
                      <span className={`text-xs font-medium ${passwordStrength().color}`}>
                        {passwordStrength().level}
                      </span>
                    </div>
                  )}
                </div>

                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-2">
                    Confirmer le mot de passe
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="password"
                      id="confirmPassword"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                      required
                      className="w-full pl-12 pr-4 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0A0A8A] focus:border-transparent outline-none transition-all text-gray-900 bg-gray-50 focus:bg-white"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-gray-50 p-4 rounded-xl">
                  <input
                    type="checkbox"
                    id="terms"
                    checked={acceptedTerms}
                    onChange={(e) => setAcceptedTerms(e.target.checked)}
                    className="w-5 h-5 mt-0.5 rounded border-gray-300 text-[#0A0A8A] focus:ring-[#0A0A8A]"
                  />
                  <label htmlFor="terms" className="text-sm text-gray-600">
                    J&apos;accepte les{' '}
                    <Link href="/legal/cgu" className="text-[#0A0A8A] hover:underline font-medium">
                      conditions d&apos;utilisation
                    </Link>
                    {' '}et la{' '}
                    <Link href="/legal/confidentialite" className="text-[#0A0A8A] hover:underline font-medium">
                      politique de confidentialité
                    </Link>
                  </label>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 py-4 px-6 border border-gray-200 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 transition-all"
                  >
                    Retour
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="flex-1 py-4 px-6 bg-[#0A0A8A] text-white font-semibold rounded-xl hover:bg-[#0A0A8A]/90 transition-all flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-[#0A0A8A]/20"
                  >
                    {isLoading ? (
                      <span className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                    ) : (
                      <>
                        <UserPlus className="w-5 h-5" />
                        Créer mon compte
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </form>

          {/* Already have account */}
          <div className="mt-8 text-center">
            <p className="text-sm text-gray-500">
              Vous avez déjà un compte ?{' '}
              <Link href="/connexion" className="text-[#0A0A8A] font-medium hover:underline">
                Se connecter
              </Link>
            </p>
          </div>

          {/* Security Badge */}
          <div className="mt-8 flex items-center justify-center gap-2 text-xs text-gray-400">
            <Shield className="w-4 h-4" />
            <span>Données hébergées en France • RGPD conforme</span>
          </div>
        </div>
      </div>
    </main>
  )
}
