import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import Link from 'next/link'

export default function CookiesPage() {
  return (
    <main className="min-h-screen bg-white">
      <SiteHeader />
      
      <section className="pt-[120px] pb-20 px-6 lg:px-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-[#0A0A8A] hover:underline text-sm">← Retour à l&apos;accueil</Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Politique Relative aux Cookies
          </h1>
          
          <p className="text-sm text-gray-500 mb-8">Dernière mise à jour : Janvier 2025</p>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-8">
            <p className="text-gray-700">
              Cette politique vous informe sur l&apos;utilisation des cookies et autres traceurs sur 
              la plateforme MAINTEX. BBC & Partners s&apos;engage à respecter votre vie privée et à 
              vous donner le contrôle sur vos données de navigation.
            </p>
          </div>
          
          <div className="prose prose-gray max-w-none">
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">1. Qu&apos;est-ce qu&apos;un cookie ?</h2>
            <p className="text-gray-600 mb-4">
              Un cookie est un petit fichier texte déposé sur votre terminal (ordinateur, tablette, 
              smartphone) lors de votre visite sur un site web ou une application. Il permet de 
              stocker des informations relatives à votre navigation et d&apos;améliorer votre expérience utilisateur.
            </p>
            <p className="text-gray-600 mb-4">
              Les cookies sont gérés par votre navigateur web et peuvent être supprimés ou bloqués 
              selon vos préférences. Ils ne contiennent pas de virus et ne peuvent pas exécuter de programmes.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">2. Pourquoi utilisons-nous des cookies ?</h2>
            <p className="text-gray-600 mb-4">
              MAINTEX utilise des cookies pour les raisons suivantes :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Fonctionnement technique</strong> : assurer le bon fonctionnement de la plateforme</li>
              <li><strong>Sécurité</strong> : protéger votre compte et vos données</li>
              <li><strong>Authentification</strong> : maintenir votre session connectée</li>
              <li><strong>Préférences</strong> : mémoriser vos paramètres et préférences</li>
              <li><strong>Performance</strong> : analyser et améliorer les performances du service</li>
              <li><strong>Support</strong> : vous assister en cas de besoin</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">3. Types de cookies utilisés</h2>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.1 Cookies strictement nécessaires</h3>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-600 mb-4">
                Ces cookies sont indispensables au fonctionnement de MAINTEX. Sans eux, la plateforme 
                ne peut pas fonctionner correctement. Ils ne peuvent pas être désactivés.
              </p>
              <table className="min-w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Nom</th>
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Finalité</th>
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Durée</th>
                  </tr>
                </thead>
                <tbody className="text-sm text-gray-600">
                  <tr className="border-b border-gray-100">
                    <td className="py-2">session_id</td>
                    <td className="py-2">Maintien de la session utilisateur</td>
                    <td className="py-2">Session</td>
                  </tr>
                  <tr className="border-b border-gray-100">
                    <td className="py-2">csrf_token</td>
                    <td className="py-2">Protection contre les attaques CSRF</td>
                    <td className="py-2">Session</td>
                  </tr>
                  <tr className="border-b border-gray-100">
                    <td className="py-2">auth_token</td>
                    <td className="py-2">Authentification persistante</td>
                    <td className="py-2">30 jours</td>
                  </tr>
                  <tr>
                    <td className="py-2">preferences</td>
                    <td className="py-2">Préférences utilisateur (langue, thème)</td>
                    <td className="py-2">1 an</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.2 Cookies de performance et analyse</h3>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-600 mb-4">
                Ces cookies nous permettent d&apos;analyser l&apos;utilisation de MAINTEX pour améliorer 
                ses performances et l&apos;expérience utilisateur. Ils sont déposés avec votre consentement.
              </p>
              <table className="min-w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Nom</th>
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Finalité</th>
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Durée</th>
                  </tr>
                </thead>
                <tbody className="text-sm text-gray-600">
                  <tr className="border-b border-gray-100">
                    <td className="py-2">_ga / _gid</td>
                    <td className="py-2">Google Analytics - Mesure d&apos;audience</td>
                    <td className="py-2">2 ans / 24h</td>
                  </tr>
                  <tr className="border-b border-gray-100">
                    <td className="py-2">_gat</td>
                    <td className="py-2">Google Analytics - Limitation du taux de requêtes</td>
                    <td className="py-2">1 minute</td>
                  </tr>
                  <tr>
                    <td className="py-2">mt_perf</td>
                    <td className="py-2">Mesure des performances de chargement</td>
                    <td className="py-2">Session</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.3 Cookies de fonctionnalité</h3>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-600 mb-4">
                Ces cookies permettent de mémoriser vos choix et de personnaliser votre expérience 
                sur MAINTEX. Ils sont déposés avec votre consentement.
              </p>
              <table className="min-w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Nom</th>
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Finalité</th>
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Durée</th>
                  </tr>
                </thead>
                <tbody className="text-sm text-gray-600">
                  <tr className="border-b border-gray-100">
                    <td className="py-2">theme</td>
                    <td className="py-2">Mémorisation du thème (clair/sombre)</td>
                    <td className="py-2">1 an</td>
                  </tr>
                  <tr className="border-b border-gray-100">
                    <td className="py-2">lang</td>
                    <td className="py-2">Mémorisation de la langue</td>
                    <td className="py-2">1 an</td>
                  </tr>
                  <tr>
                    <td className="py-2">layout</td>
                    <td className="py-2">Préférences d&apos;affichage</td>
                    <td className="py-2">6 mois</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.4 Cookies de support</h3>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-600 mb-4">
                Ces cookies sont utilisés par notre outil de support client pour faciliter 
                l&apos;assistance technique.
              </p>
              <table className="min-w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Outil</th>
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Finalité</th>
                    <th className="text-left py-2 text-sm font-semibold text-gray-900">Durée</th>
                  </tr>
                </thead>
                <tbody className="text-sm text-gray-600">
                  <tr className="border-b border-gray-100">
                    <td className="py-2">Intercom</td>
                    <td className="py-2">Chat de support et messagerie</td>
                    <td className="py-2">1 an</td>
                  </tr>
                  <tr>
                    <td className="py-2">Crisp</td>
                    <td className="py-2">Messagerie et support client</td>
                    <td className="py-2">6 mois</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">4. Cookies tiers</h2>
            <p className="text-gray-600 mb-4">
              MAINTEX peut intégrer des services tiers qui déposent leurs propres cookies. 
              Ces tiers sont soumis à leurs propres politiques de confidentialité :
            </p>
            
            <div className="overflow-x-auto mb-4">
              <table className="min-w-full border border-gray-200 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Tiers</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Finalité</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Politique de confidentialité</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 text-sm text-gray-600">
                  <tr>
                    <td className="px-4 py-3">Google Analytics</td>
                    <td className="px-4 py-3">Mesure d&apos;audience et statistiques</td>
                    <td className="px-4 py-3">
                      <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" className="text-[#0A0A8A] hover:underline">policies.google.com</a>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Intercom</td>
                    <td className="px-4 py-3">Support client et messagerie</td>
                    <td className="px-4 py-3">
                      <a href="https://www.intercom.com/legal/privacy" target="_blank" rel="noopener noreferrer" className="text-[#0A0A8A] hover:underline">intercom.com/legal/privacy</a>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Stripe</td>
                    <td className="px-4 py-3">Paiement sécurisé</td>
                    <td className="px-4 py-3">
                      <a href="https://stripe.com/privacy" target="_blank" rel="noopener noreferrer" className="text-[#0A0A8A] hover:underline">stripe.com/privacy</a>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Sentry</td>
                    <td className="px-4 py-3">Suivi des erreurs techniques</td>
                    <td className="px-4 py-3">
                      <a href="https://sentry.io/privacy/" target="_blank" rel="noopener noreferrer" className="text-[#0A0A8A] hover:underline">sentry.io/privacy</a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">5. Durée de conservation des cookies</h2>
            <p className="text-gray-600 mb-4">
              La durée de vie des cookies varie selon leur finalité :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Cookies de session</strong> : supprimés à la fermeture du navigateur</li>
              <li><strong>Cookies persistants</strong> : durée maximale de 13 mois conformément aux recommandations de la CNIL</li>
              <li><strong>Cookies de consentement</strong> : 13 mois maximum, après quoi un nouveau consentement est demandé</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">6. Gestion de vos préférences</h2>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">6.1 Via notre bandeau de consentement</h3>
            <p className="text-gray-600 mb-4">
              Lors de votre première visite sur MAINTEX, un bandeau vous permet de :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Accepter tous les cookies</strong> : autorise l&apos;ensemble des cookies</li>
              <li><strong>Refuser tous les cookies non essentiels</strong> : seuls les cookies strictement nécessaires sont déposés</li>
              <li><strong>Personnaliser vos choix</strong> : sélectionner les catégories de cookies que vous acceptez</li>
            </ul>
            <p className="text-gray-600 mb-4">
              Vous pouvez modifier vos préférences à tout moment en cliquant sur le lien 
              &quot;Gestion des cookies&quot; en bas de chaque page ou dans vos paramètres utilisateur.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">6.2 Via les paramètres de votre navigateur</h3>
            <p className="text-gray-600 mb-4">
              Vous pouvez configurer votre navigateur pour gérer les cookies :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Chrome</strong> : Paramètres → Confidentialité et sécurité → Cookies et autres données de sites</li>
              <li><strong>Firefox</strong> : Options → Vie privée et sécurité → Cookies et données de sites</li>
              <li><strong>Safari</strong> : Préférences → Confidentialité → Cookies et données de sites web</li>
              <li><strong>Edge</strong> : Paramètres → Cookies et autorisations de site → Cookies et données de site</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">6.3 Conséquences du refus des cookies</h3>
            <p className="text-gray-600 mb-4">
              Le refus des cookies peut entraîner :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Une expérience utilisateur moins personnalisée</li>
              <li>L&apos;impossibilité de mémoriser certaines préférences</li>
              <li>Des statistiques d&apos;utilisation moins précises pour améliorer le service</li>
              <li>La désactivation de certaines fonctionnalités (chat de support, etc.)</li>
            </ul>
            <p className="text-gray-600 mb-4">
              <strong>Note :</strong> Les cookies strictement nécessaires ne peuvent pas être refusés car 
              ils sont indispensables au fonctionnement de MAINTEX.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">7. Autres traceurs</h2>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">7.1 Local Storage et Session Storage</h3>
            <p className="text-gray-600 mb-4">
              MAINTEX utilise le stockage local du navigateur (Local Storage et Session Storage) 
              pour mémoriser des données de session, des préférences utilisateur et des caches 
              de données. Ces données restent sur votre appareil et ne sont pas transmises à nos serveurs.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">7.2 Pixels et balises</h3>
            <p className="text-gray-600 mb-4">
              Nous utilisons des pixels de tracking pour les emails marketing (taux d&apos;ouverture, 
              clics). Ces pixels sont uniquement activés si vous avez donné votre consentement 
              pour recevoir des communications marketing.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">7.3 Empreintes numériques</h3>
            <p className="text-gray-600 mb-4">
              MAINTEX n&apos;utilise pas de techniques d&apos;empreinte numérique (fingerprinting) pour 
              le tracking des utilisateurs sans leur consentement explicite.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">8. Mise à jour de la politique</h2>
            <p className="text-gray-600 mb-4">
              Cette politique relative aux cookies peut être mise à jour périodiquement. 
              En cas de modification substantielle, vous serez informé par un nouveau bandeau 
              de consentement lors de votre prochaine visite.
            </p>
            <p className="text-gray-600 mb-4">
              La date de dernière mise à jour est indiquée en tête de ce document.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">9. Vos droits</h2>
            <p className="text-gray-600 mb-4">
              Conformément au RGPD et à la directive ePrivacy, vous disposez des droits suivants :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Droit d&apos;information</strong> : être informé de l&apos;utilisation des cookies</li>
              <li><strong>Droit de consentement</strong> : donner ou refuser votre consentement</li>
              <li><strong>Droit d&apos;opposition</strong> : vous opposer à certains traitements</li>
              <li><strong>Droit d&apos;accès</strong> : savoir quelles données sont collectées</li>
              <li><strong>Droit de suppression</strong> : demander la suppression de vos données</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">10. Contact</h2>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>Pour toute question relative aux cookies</strong><br />
                Email : <a href="mailto:privacy@maintex.fr" className="text-[#0A0A8A] hover:underline">privacy@maintex.fr</a><br /><br />
                <strong>Pour exercer vos droits RGPD</strong><br />
                DPO : <a href="mailto:dpo@maintex.fr" className="text-[#0A0A8A] hover:underline">dpo@maintex.fr</a><br /><br />
                <strong>BBC & Partners SAS</strong><br />
                Éditeur de MAINTEX
              </p>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">11. Réclamation</h2>
            <p className="text-gray-600 mb-4">
              Si vous estimez que le traitement de vos données via les cookies n&apos;est pas conforme 
              à la réglementation, vous pouvez introduire une réclamation auprès de la CNIL :
            </p>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4">
              <p className="text-gray-700">
                <strong>CNIL</strong><br />
                3 Place de Fontenoy - TSA 80715<br />
                75334 Paris Cedex 07<br />
                Site web : <a href="https://www.cnil.fr" target="_blank" rel="noopener noreferrer" className="text-[#0A0A8A] hover:underline">www.cnil.fr</a>
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <SiteFooter />
    </main>
  )
}
