import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import Link from 'next/link'

export default function ConfidentialitePage() {
  return (
    <main className="min-h-screen bg-white">
      <SiteHeader />
      
      <section className="pt-[120px] pb-20 px-6 lg:px-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-[#0A0A8A] hover:underline text-sm">← Retour à l&apos;accueil</Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Politique de Confidentialité
          </h1>
          
          <p className="text-sm text-gray-500 mb-8">Dernière mise à jour : Janvier 2025</p>
          
          <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-8">
            <p className="text-green-800">
              <strong>Engagement de BBC & Partners</strong><br />
              En tant qu&apos;éditeur de MAINTEX, solution de GMAO professionnelle, nous nous engageons 
              à protéger la vie privée de nos utilisateurs. Toutes vos données sont hébergées en France 
              et traitées conformément au Règlement Général sur la Protection des Données (RGPD).
            </p>
          </div>
          
          <div className="prose prose-gray max-w-none">
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">1. Introduction</h2>
            <p className="text-gray-600 mb-4">
              La présente Politique de Confidentialité a pour objet de vous informer sur la manière 
              dont BBC & Partners, en tant que responsable de traitement, collecte et traite vos 
              données personnelles dans le cadre de votre utilisation de MAINTEX.
            </p>
            <p className="text-gray-600 mb-4">
              Cette politique s&apos;applique à tous les utilisateurs de la solution MAINTEX, qu&apos;ils 
              soient administrateurs, techniciens, gestionnaires ou tout autre profil d&apos;utilisateur.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">2. Responsable de traitement</h2>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>BBC & Partners SAS</strong><br />
                Société par Actions Simplifiée<br />
                Capital social : [Montant]<br />
                RCS [Ville] : [Numéro]<br />
                Siège social : [Adresse complète]<br />
                SIRET : [Numéro SIRET]<br />
                Téléphone : +33 1 XX XX XX XX<br />
                Email : <a href="mailto:contact@maintex.fr" className="text-[#0A0A8A] hover:underline">contact@maintex.fr</a>
              </p>
            </div>
            <p className="text-gray-600 mb-4">
              Pour toute question relative à la protection de vos données personnelles, vous pouvez 
              contacter notre Délégué à la Protection des Données (DPO) à l&apos;adresse : 
              <a href="mailto:dpo@maintex.fr" className="text-[#0A0A8A] hover:underline"> dpo@maintex.fr</a>
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">3. Données collectées</h2>
            <p className="text-gray-600 mb-4">
              Nous collectons les données nécessaires au bon fonctionnement de MAINTEX et à la 
              fourniture de nos services de GMAO :
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.1 Données d&apos;identification</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Nom et prénom</li>
              <li>Adresse email professionnelle</li>
              <li>Numéro de téléphone professionnel</li>
              <li>Photo de profil (optionnelle)</li>
              <li>Fonction au sein de l&apos;entreprise</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.2 Données professionnelles</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Nom de l&apos;entreprise ou de l&apos;organisation</li>
              <li>Adresse de l&apos;entreprise</li>
              <li>SIRET / Numéro de TVA intracommunautaire</li>
              <li>Secteur d&apos;activité</li>
              <li>Service ou département d&apos;affectation</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.3 Données d&apos;utilisation</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Historique de connexion (dates, heures, durées)</li>
              <li>Actions effectuées dans l&apos;application</li>
              <li>Préférences utilisateur (langue, notifications, affichage)</li>
              <li>Favoris et filtres personnalisés</li>
              <li>Historique des interventions créées ou modifiées</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.4 Données techniques</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Adresse IP</li>
              <li>Type et version du navigateur</li>
              <li>Système d&apos;exploitation</li>
              <li>Type d&apos;appareil (desktop, mobile, tablette)</li>
              <li>Identifiants uniques de session</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.5 Données métier</h3>
            <p className="text-gray-600 mb-4">
              Dans le cadre de l&apos;utilisation de MAINTEX pour la gestion de maintenance, les 
              données suivantes peuvent être stockées :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Informations sur les équipements (désignation, localisation, caractéristiques)</li>
              <li>Historique de maintenance des équipements</li>
              <li>Comptes-rendus d&apos;intervention</li>
              <li>Données de stock (pièces détachées, consommables)</li>
              <li>Planning et affectation des équipes techniques</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">4. Finalités du traitement</h2>
            <p className="text-gray-600 mb-4">Vos données sont traitées pour les finalités suivantes :</p>
            
            <div className="overflow-x-auto mb-4">
              <table className="min-w-full border border-gray-200 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Finalité</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Base légale</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-600">Fourniture des services MAINTEX</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Exécution du contrat</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-600">Gestion du compte utilisateur</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Exécution du contrat</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-600">Support technique</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Exécution du contrat</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-600">Amélioration des services</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Intérêt légitime</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-600">Communications commerciales</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Consentement</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-600">Respect des obligations légales</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Obligation légale</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3 text-sm text-gray-600">Sécurité des systèmes</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Intérêt légitime</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">5. Destinataires des données</h2>
            <p className="text-gray-600 mb-4">
              Vos données sont accessibles uniquement aux personnes habilitées et nécessaires 
              au traitement :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Personnel de BBC & Partners</strong> : équipes techniques, support client, administration</li>
              <li><strong>Sous-traitants</strong> : hébergeurs, prestataires de paiement, services de support</li>
              <li><strong>Membres de votre organisation</strong> : selon les droits d&apos;accès configurés</li>
            </ul>
            <p className="text-gray-600 mb-4">
              <strong>Important :</strong> Vos données ne sont jamais vendues ou louées à des tiers à des fins commerciales.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">5.1 Sous-traitants</h3>
            <p className="text-gray-600 mb-4">
              Nous faisons appel à des sous-traitants pour certains services. Tous sont conformes 
              au RGPD et ont signé des clauses de confidentialité :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Hébergement</strong> : data centers certifiés ISO 27001, situés en France</li>
              <li><strong>Paiement</strong> : prestataire de paiement sécurisé agréé</li>
              <li><strong>Support</strong> : plateforme de ticketing et communication</li>
              <li><strong>Analytique</strong> : outils de mesure d&apos;audience (avec consentement)</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">6. Transferts de données hors UE</h2>
            <p className="text-gray-600 mb-4">
              <strong>Engagement :</strong> Toutes vos données sont hébergées en France métropolitaine, 
              dans des data centers certifiés ISO 27001. Aucun transfert de données hors de l&apos;Union 
              Européenne n&apos;est effectué.
            </p>
            <p className="text-gray-600 mb-4">
              Dans l&apos;hypothèse où certains sous-traitants seraient situés hors de l&apos;UE, nous 
              nous assurerions que des garanties appropriées (clauses contractuelles types de la 
              Commission européenne) sont mises en place.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">7. Durée de conservation</h2>
            <p className="text-gray-600 mb-4">
              Vos données sont conservées selon les critères suivants :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Données de compte</strong> : durée de la relation contractuelle + 3 ans</li>
              <li><strong>Données de facturation</strong> : 10 ans (obligations comptables)</li>
              <li><strong>Logs de connexion</strong> : 1 an (obligations légales)</li>
              <li><strong>Données métier</strong> : durée de la relation contractuelle + 5 ans</li>
              <li><strong>Cookies</strong> : 13 mois maximum</li>
            </ul>
            <p className="text-gray-600 mb-4">
              Au-delà de ces durées, les données sont anonymisées ou supprimées définitivement.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">8. Vos droits</h2>
            <p className="text-gray-600 mb-4">
              Conformément au Règlement Général sur la Protection des Données, vous disposez des droits suivants :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Droit d&apos;accès (article 15 RGPD)</strong> : obtenir la confirmation que vos données sont traitées et en recevoir une copie</li>
              <li><strong>Droit de rectification (article 16 RGPD)</strong> : faire corriger les données inexactes ou incomplètes</li>
              <li><strong>Droit à l&apos;effacement (article 17 RGPD)</strong> : demander la suppression de vos données dans certains cas</li>
              <li><strong>Droit à la limitation (article 18 RGPD)</strong> : demander la suspension temporaire du traitement</li>
              <li><strong>Droit à la portabilité (article 20 RGPD)</strong> : recevoir vos données dans un format structuré et lisible par machine</li>
              <li><strong>Droit d&apos;opposition (article 21 RGPD)</strong> : vous opposer au traitement fondé sur l&apos;intérêt légitime</li>
              <li><strong>Droit de retirer votre consentement</strong> : à tout moment pour les traitements fondés sur le consentement</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">8.1 Comment exercer vos droits</h3>
            <p className="text-gray-600 mb-4">
              Pour exercer vos droits, contactez notre DPO par email : 
              <a href="mailto:dpo@maintex.fr" className="text-[#0A0A8A] hover:underline"> dpo@maintex.fr</a>
            </p>
            <p className="text-gray-600 mb-4">
              Vous pouvez également nous adresser une demande écrite accompagnée d&apos;une copie de 
              votre pièce d&apos;identité à l&apos;adresse postale de BBC & Partners.
            </p>
            <p className="text-gray-600 mb-4">
              Nous nous engageons à répondre à votre demande dans un délai d&apos;un mois, délai qui 
              peut être prolongé de deux mois supplémentaires en cas de complexité.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">8.2 Réclamation auprès de la CNIL</h3>
            <p className="text-gray-600 mb-4">
              Si vous estimez que le traitement de vos données n&apos;est pas conforme à la réglementation, 
              vous avez le droit d&apos;introduire une réclamation auprès de la Commission Nationale de 
              l&apos;Informatique et des Libertés (CNIL) :
            </p>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4">
              <p className="text-gray-700">
                <strong>CNIL</strong><br />
                3 Place de Fontenoy - TSA 80715<br />
                75334 Paris Cedex 07<br />
                Site web : <a href="https://www.cnil.fr" target="_blank" rel="noopener noreferrer" className="text-[#0A0A8A] hover:underline">www.cnil.fr</a>
              </p>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">9. Sécurité des données</h2>
            <p className="text-gray-600 mb-4">
              Nous mettons en œuvre des mesures techniques et organisationnelles appropriées pour 
              protéger vos données personnelles :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Chiffrement</strong> : toutes les communications sont chiffrées en TLS 1.3, les données sensibles sont chiffrées au repos</li>
              <li><strong>Contrôle d&apos;accès</strong> : accès restreint aux données selon le principe du moindre privilège</li>
              <li><strong>Authentification</strong> : authentification forte, politique de mots de passe robuste</li>
              <li><strong>Audit</strong> : traçabilité des accès et des opérations, audits de sécurité réguliers</li>
              <li><strong>Infrastructure</strong> : hébergement en data centers certifiés ISO 27001 en France</li>
              <li><strong>Sauvegarde</strong> : sauvegardes quotidiennes avec chiffrement et tests de restauration</li>
              <li><strong>Formation</strong> : sensibilisation régulière de nos équipes à la protection des données</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">9.1 Notification de violation de données</h3>
            <p className="text-gray-600 mb-4">
              En cas de violation de données personnelles susceptible d&apos;engendrer un risque élevé 
              pour vos droits et libertés, nous nous engageons à vous en informer dans les meilleurs 
              délais, conformément à l&apos;article 34 du RGPD.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">10. Cookies et traceurs</h2>
            <p className="text-gray-600 mb-4">
              Pour plus d&apos;informations sur l&apos;utilisation des cookies, consultez notre 
              <Link href="/legal/cookies" className="text-[#0A0A8A] hover:underline"> Politique Relative aux Cookies</Link>.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">11. Modifications de la politique</h2>
            <p className="text-gray-600 mb-4">
              Nous nous réservons le droit de modifier cette politique à tout moment. Les utilisateurs 
              seront informés des modifications substantielles par notification dans l&apos;application ou 
              par email. La date de dernière mise à jour est indiquée en tête de ce document.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">12. Contact</h2>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>Délégué à la Protection des Données (DPO)</strong><br />
                Email : <a href="mailto:dpo@maintex.fr" className="text-[#0A0A8A] hover:underline">dpo@maintex.fr</a><br /><br />
                <strong>BBC & Partners SAS</strong><br />
                Éditeur de MAINTEX<br />
                Email : <a href="mailto:contact@maintex.fr" className="text-[#0A0A8A] hover:underline">contact@maintex.fr</a>
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <SiteFooter />
    </main>
  )
}
