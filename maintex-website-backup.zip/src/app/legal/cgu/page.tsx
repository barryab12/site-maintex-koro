import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import Link from 'next/link'

export default function CGUPage() {
  return (
    <main className="min-h-screen bg-white">
      <SiteHeader />
      
      <section className="pt-[120px] pb-20 px-6 lg:px-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-[#0A0A8A] hover:underline text-sm">← Retour à l&apos;accueil</Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Conditions Générales d&apos;Utilisation
          </h1>
          
          <p className="text-sm text-gray-500 mb-8">Dernière mise à jour : Janvier 2025</p>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-8">
            <p className="text-gray-700">
              Les présentes Conditions Générales d&apos;Utilisation (CGU) régissent l&apos;accès et l&apos;utilisation 
              de la solution MAINTEX, logiciel de GMAO (Gestion de Maintenance Assistée par Ordinateur) 
              éditée par BBC & Partners. En utilisant MAINTEX, vous acceptez ces conditions sans réserve.
            </p>
          </div>
          
          <div className="prose prose-gray max-w-none">
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 1 - Objet</h2>
            <p className="text-gray-600 mb-4">
              Les présentes CGU ont pour objet de définir les modalités et conditions d&apos;utilisation 
              de la plateforme MAINTEX, ainsi que de définir les droits et obligations des parties 
              dans le cadre de son utilisation.
            </p>
            <p className="text-gray-600 mb-4">
              MAINTEX est une solution de GMAO (Gestion de Maintenance Assistée par Ordinateur) 
              destinée aux professionnels pour gérer leurs opérations de maintenance, leurs équipements, 
              leurs interventions et leurs équipes techniques.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 2 - Définitions</h2>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Plateforme</strong> : L&apos;ensemble des services MAINTEX accessibles via l&apos;interface web et les applications mobiles (iOS et Android)</li>
              <li><strong>Éditeur</strong> : BBC & Partners SAS, société par actions simplifiée au capital de [montant], immatriculée au RCS de [ville] sous le numéro [SIRET], dont le siège social est situé [adresse]</li>
              <li><strong>Utilisateur</strong> : Toute personne physique ou morale utilisant la plateforme après création d&apos;un compte</li>
              <li><strong>Compte</strong> : L&apos;espace personnel créé par l&apos;utilisateur pour accéder aux services</li>
              <li><strong>Données</strong> : Toute information stockée et traitée par la plateforme</li>
              <li><strong>Abonnement</strong> : Le contrat souscrit par l&apos;utilisateur pour accéder aux services MAINTEX</li>
              <li><strong>Module</strong> : Chaque composant fonctionnel de la solution (maintenance préventive, gestion des stocks, etc.)</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 3 - Acceptation des conditions</h2>
            <p className="text-gray-600 mb-4">
              L&apos;utilisation de MAINTEX implique l&apos;acceptation pleine et entière des présentes CGU. 
              Si vous n&apos;acceptez pas ces conditions, vous ne devez pas utiliser la plateforme.
            </p>
            <p className="text-gray-600 mb-4">
              Les CGU peuvent être modifiées à tout moment par BBC & Partners. Les utilisateurs seront 
              informés de toute modification substantielle par notification dans l&apos;application ou par email. 
              L&apos;utilisation continue de la plateforme après modification vaut acceptation des nouvelles conditions.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 4 - Conditions d&apos;accès au service</h2>
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">4.1 Inscription</h3>
            <p className="text-gray-600 mb-4">
              L&apos;accès à MAINTEX nécessite la création d&apos;un compte. L&apos;utilisateur s&apos;engage à fournir 
              des informations exactes, complètes et à jour lors de son inscription et tout au long 
              de l&apos;utilisation du service.
            </p>
            <p className="text-gray-600 mb-4">
              L&apos;inscription est réservée aux personnes physiques âgées de 18 ans ou plus, ou aux 
              personnes morales agissant par l&apos;intermédiaire d&apos;un représentant légal.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">4.2 Identifiants</h3>
            <p className="text-gray-600 mb-4">
              L&apos;utilisateur est responsable de la confidentialité de ses identifiants de connexion 
              (email et mot de passe). Toute connexion effectuée avec ses identifiants est réputée 
              effectuée par l&apos;utilisateur lui-même.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">4.3 Suspension et résiliation</h3>
            <p className="text-gray-600 mb-4">
              BBC & Partners se réserve le droit de suspendre ou supprimer tout compte en cas de :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Non-respect des présentes CGU</li>
              <li>Fourniture de fausses informations lors de l&apos;inscription</li>
              <li>Utilisation frauduleuse ou abusive du service</li>
              <li>Non-paiement des sommes dues</li>
              <li>Inactivité prolongée du compte</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 5 - Description des services</h2>
            <p className="text-gray-600 mb-4">
              MAINTEX offre les fonctionnalités suivantes selon les modules souscrits :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Gestion des équipements</strong> : création et suivi du parc matériel, historique des interventions</li>
              <li><strong>Maintenance préventive</strong> : planification des maintenances régulières, calendrier des interventions</li>
              <li><strong>Maintenance corrective</strong> : gestion des pannes et incidents, suivi des réparations</li>
              <li><strong>Gestion des stocks</strong> : inventaire des pièces détachées, alertes de réapprovisionnement</li>
              <li><strong>Gestion des équipes</strong> : attribution des tâches, suivi des techniciens</li>
              <li><strong>Rapports et tableaux de bord</strong> : indicateurs de performance, exports personnalisés</li>
              <li><strong>Application mobile</strong> : accès terrain via iOS et Android</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 6 - Obligations de l&apos;utilisateur</h2>
            <p className="text-gray-600 mb-4">L&apos;utilisateur s&apos;engage à :</p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Utiliser la plateforme de manière légale et conforme à sa destination professionnelle</li>
              <li>Respecter les droits de propriété intellectuelle de BBC & Partners</li>
              <li>Ne pas porter atteinte aux droits de tiers</li>
              <li>Ne pas tenter d&apos;accéder à des données non autorisées</li>
              <li>Signaler toute anomalie, bug ou incident de sécurité à support@maintex.fr</li>
              <li>Maintenir ses informations à jour</li>
              <li>Respecter la politique d&apos;utilisation acceptable</li>
              <li>Régler les sommes dues dans les délais convenus</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 7 - Obligations de BBC & Partners</h2>
            <p className="text-gray-600 mb-4">BBC & Partners s&apos;engage à :</p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Assurer l&apos;accessibilité de la plateforme avec un taux de disponibilité de 99,5%</li>
              <li>Mettre en œuvre des mesures de sécurité appropriées</li>
              <li>Assurer la maintenance et les mises à jour du logiciel</li>
              <li>Fournir un support technique selon les conditions définies dans la Politique de Support</li>
              <li>Héberger les données en France conformément au RGPD</li>
              <li>Informer les utilisateurs des évolutions majeures du service</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 8 - Propriété intellectuelle</h2>
            <p className="text-gray-600 mb-4">
              L&apos;ensemble des éléments constituant MAINTEX (marques, logos, design, code source, 
              documentation, bases de données) sont la propriété exclusive de BBC & Partners et 
              sont protégés par les lois françaises et internationales relatives à la propriété intellectuelle.
            </p>
            <p className="text-gray-600 mb-4">
              Toute reproduction, représentation, modification, publication, adaptation de tout ou 
              partie des éléments de la plateforme, quel que soit le moyen ou le procédé utilisé, 
              est interdite sans autorisation écrite préalable de BBC & Partners.
            </p>
            <p className="text-gray-600 mb-4">
              L&apos;utilisateur conserve la propriété de ses données et des contenus qu&apos;il crée ou 
              importe dans la plateforme.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 9 - Tarification et paiement</h2>
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">9.1 Tarifs</h3>
            <p className="text-gray-600 mb-4">
              Les tarifs de MAINTEX sont indiqués sur le site internet et dans les devis fournis. 
              Les prix sont exprimés en euros hors taxes. La TVA applicable sera ajoutée au taux en vigueur.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">9.2 Modalités de paiement</h3>
            <p className="text-gray-600 mb-4">
              Le paiement s&apos;effectue par prélèvement automatique ou virement bancaire selon les 
              conditions définies dans le contrat d&apos;abonnement. Les factures sont émises mensuellement 
              ou annuellement selon l&apos;échéance choisie.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">9.3 Modification des tarifs</h3>
            <p className="text-gray-600 mb-4">
              BBC & Partners se réserve le droit de modifier ses tarifs avec un préavis de 30 jours. 
              L&apos;utilisateur peut refuser la modification en résiliant son abonnement avant l&apos;entrée 
              en vigueur des nouveaux tarifs.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 10 - Responsabilité et garantie</h2>
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">10.1 Limitation de responsabilité</h3>
            <p className="text-gray-600 mb-4">
              BBC & Partners s&apos;efforce d&apos;assurer la disponibilité et la sécurité de la plateforme. 
              Cependant, la responsabilité de BBC & Partners ne pourra être engagée en cas de :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Force majeure ou cas fortuit</li>
              <li>Faute de l&apos;utilisateur</li>
              <li>Utilisation non conforme aux CGU</li>
              <li>Détérioration ou anomalie liée à un tiers</li>
              <li>Maintenance programmée annoncée</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">10.2 Garantie</h3>
            <p className="text-gray-600 mb-4">
              BBC & Partners garantit que la plateforme fonctionne conformément à sa documentation. 
              En cas de dysfonctionnement, l&apos;utilisateur peut demander la réparation du service ou, 
              à défaut de réparation dans un délai raisonnable, la résiliation du contrat.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 11 - Protection des données</h2>
            <p className="text-gray-600 mb-4">
              Le traitement des données personnelles est décrit dans la 
              <Link href="/legal/confidentialite" className="text-[#0A0A8A] hover:underline"> Politique de Confidentialité</Link> et la 
              <Link href="/legal/rgpd" className="text-[#0A0A8A] hover:underline"> Politique de Conformité RGPD</Link>.
            </p>
            <p className="text-gray-600 mb-4">
              Les données sont hébergées en France et traitées conformément au Règlement Général 
              sur la Protection des Données (RGPD).
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 12 - Durée et résiliation</h2>
            <p className="text-gray-600 mb-4">
              Les présentes CGU sont conclues pour une durée indéterminée pour chaque abonnement souscrit.
            </p>
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">12.1 Résiliation par l&apos;utilisateur</h3>
            <p className="text-gray-600 mb-4">
              L&apos;utilisateur peut résilier son abonnement à tout moment avec un préavis de 30 jours 
              avant la prochaine échéance, par notification écrite à legal@maintex.fr.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">12.2 Résiliation par BBC & Partners</h3>
            <p className="text-gray-600 mb-4">
              BBC & Partners peut résilier l&apos;abonnement en cas de non-respect des CGU, avec un 
              préavis de 30 jours sauf en cas de faute grave.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">12.3 Conséquences de la résiliation</h3>
            <p className="text-gray-600 mb-4">
              À la résiliation, l&apos;utilisateur peut demander l&apos;export de ses données dans un délai 
              de 30 jours. Passé ce délai, les données seront supprimées définitivement.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 13 - Litiges et droit applicable</h2>
            <p className="text-gray-600 mb-4">
              Les présentes CGU sont régies par le droit français. En cas de litige, les parties 
              s&apos;engagent à rechercher une solution amiable avant toute action judiciaire.
            </p>
            <p className="text-gray-600 mb-4">
              À défaut d&apos;accord amiable, les litiges seront soumis aux tribunaux compétents de Paris, 
              nonobstant pluralité de défendeurs ou appel en garantie.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 14 - Dispositions diverses</h2>
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">14.1 Non-renonciation</h3>
            <p className="text-gray-600 mb-4">
              Le fait pour BBC & Partners de ne pas faire application d&apos;une disposition des CGU 
              ne saurait être interprété comme une renonciation à cette disposition.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">14.2 Validité</h3>
            <p className="text-gray-600 mb-4">
              Si une disposition des CGU est déclarée nulle, les autres dispositions restent en vigueur.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">14.3 Intégralité</h3>
            <p className="text-gray-600 mb-4">
              Les CGU constituent l&apos;intégralité de l&apos;accord entre les parties et remplacent tous 
              accords antérieurs relatifs à l&apos;utilisation de MAINTEX.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Article 15 - Contact</h2>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>BBC & Partners SAS</strong><br />
                Éditeur de MAINTEX<br /><br />
                <strong>Questions juridiques :</strong> <a href="mailto:legal@maintex.fr" className="text-[#0A0A8A] hover:underline">legal@maintex.fr</a><br />
                <strong>Support technique :</strong> <a href="mailto:support@maintex.fr" className="text-[#0A0A8A] hover:underline">support@maintex.fr</a><br />
                <strong>Protection des données :</strong> <a href="mailto:dpo@maintex.fr" className="text-[#0A0A8A] hover:underline">dpo@maintex.fr</a>
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <SiteFooter />
    </main>
  )
}
