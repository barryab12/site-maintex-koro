import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import Link from 'next/link'

export default function UtilisationAcceptablePage() {
  return (
    <main className="min-h-screen bg-white">
      <SiteHeader />
      
      <section className="pt-[120px] pb-20 px-6 lg:px-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-[#0A0A8A] hover:underline text-sm">← Retour à l&apos;accueil</Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Politique d&apos;Utilisation Acceptable
          </h1>
          
          <p className="text-sm text-gray-500 mb-8">Dernière mise à jour : Janvier 2025</p>
          
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-6 mb-8">
            <p className="text-orange-800">
              Cette politique définit les règles d&apos;utilisation acceptable de la plateforme MAINTEX. 
              Elle a pour objectif de garantir un environnement sécurisé et professionnel pour 
              tous les utilisateurs de notre solution de GMAO.
            </p>
          </div>
          
          <div className="prose prose-gray max-w-none">
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">1. Objet et portée</h2>
            <p className="text-gray-600 mb-4">
              La présente Politique d&apos;Utilisation Acceptable (PUA) définit les règles que tous 
              les utilisateurs de MAINTEX doivent respecter lors de l&apos;utilisation de la plateforme. 
              Elle complète les Conditions Générales d&apos;Utilisation (CGU) et s&apos;applique à tous 
              les services proposés par BBC & Partners dans le cadre de MAINTEX.
            </p>
            <p className="text-gray-600 mb-4">
              Cette politique s&apos;applique à :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>L&apos;interface web de MAINTEX</li>
              <li>Les applications mobiles iOS et Android</li>
              <li>L&apos;API et les intégrations tierces</li>
              <li>Tous les modules et fonctionnalités de la plateforme</li>
              <li>Tous les utilisateurs (administrateurs, techniciens, gestionnaires, etc.)</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">2. Utilisations autorisées</h2>
            <p className="text-gray-600 mb-4">
              MAINTEX est une solution de GMAO conçue pour un usage professionnel. Vous êtes 
              autorisé à :
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">2.1 Usage professionnel</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Utiliser MAINTEX pour vos besoins légitimes de gestion de maintenance</li>
              <li>Gérer vos équipements, interventions et équipes techniques</li>
              <li>Stocker des données professionnelles liées à votre activité</li>
              <li>Partager votre compte avec vos collaborateurs autorisés (dans la limite des licences souscrites)</li>
              <li>Exporter vos propres données dans les formats proposés</li>
              <li>Utiliser l&apos;API pour intégrer MAINTEX à vos systèmes d&apos;information</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">2.2 Personnalisation</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Créer des champs personnalisés adaptés à votre métier</li>
              <li>Configurer des workflows selon vos processus internes</li>
              <li>Personnaliser les rapports et tableaux de bord</li>
              <li>Définir des rôles et permissions pour votre équipe</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">2.3 Collaboration</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Inviter des membres de votre organisation à rejoindre votre espace</li>
              <li>Partager des informations avec les utilisateurs autorisés</li>
              <li>Collaborer sur les interventions et les équipements</li>
              <li>Communiquer via les fonctionnalités de messagerie intégrées</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">3. Utilisations interdites</h2>
            <p className="text-gray-600 mb-4">
              Les utilisations suivantes sont strictement interdites et peuvent entraîner 
              la suspension immédiate de votre compte :
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.1 Activités illégales</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Utiliser MAINTEX à des fins illégales, frauduleuses ou nuisibles</li>
              <li>Stocker, partager ou diffuser des contenus illicites (contenus protégés par le droit d&apos;auteur sans autorisation, contenus diffamatoires, etc.)</li>
              <li>Utiliser MAINTEX pour violer les droits de tiers</li>
              <li>Se livrer à des activités de blanchiment d&apos;argent ou de financement du terrorisme</li>
              <li>Violer les lois applicables en matière d&apos;exportation ou de contrôle des exportations</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.2 Atteintes à la sécurité</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Tenter d&apos;accéder à des données ou des systèmes non autorisés</li>
              <li>Contourner les mesures de sécurité de MAINTEX</li>
              <li>Tester ou scanner les vulnérabilités du système sans autorisation préalable</li>
              <li>Introduire des virus, chevaux de Troie, vers ou autres codes malveillants</li>
              <li>Lancer des attaques par déni de service (DDoS) ou tentatives de saturation</li>
              <li>Effectuer de l&apos;ingénierie sociale pour obtenir des identifiants d&apos;autres utilisateurs</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.3 Utilisation abusive des ressources</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Utiliser des scripts automatisés, bots ou scrapeurs sans autorisation écrite</li>
              <li>Générer un trafic excessif susceptible de perturber le service</li>
              <li>Stocker des données dont le volume dépasse raisonnablement l&apos;usage prévu</li>
              <li>Utiliser MAINTEX comme espace de stockage générique (backup, fichiers non liés à la maintenance)</li>
              <li>Miner des cryptomonnaies ou effectuer des calculs intensifs non liés au service</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.4 Atteintes à la propriété intellectuelle</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Procéder à de l&apos;ingénierie inverse du logiciel</li>
              <li>Décompiler, désassembler ou extraire le code source</li>
              <li>Reproduire, copier ou distribuer des parties de MAINTEX</li>
              <li>Modifier ou créer des œuvres dérivées de MAINTEX</li>
              <li>Utiliser les marques, logos ou contenus de MAINTEX sans autorisation</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.5 Usurpation et fraude</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Usurper l&apos;identité d&apos;un tiers ou d&apos;un employé de BBC & Partners</li>
              <li>Fournir de fausses informations lors de l&apos;inscription</li>
              <li>Créer des comptes sous de fausses identités</li>
              <li>Transférer ou vendre votre compte à un tiers</li>
              <li>Partager vos identifiants avec des personnes non autorisées</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.6 Contenus inappropriés</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Stocker des contenus offensants, haineux ou discriminatoires</li>
              <li>Stocker des contenus à caractère pornographique ou pédopornographique</li>
              <li>Stocker des contenus violents ou glorifiant la violence</li>
              <li>Stocker des données personnelles d&apos;utilisateurs sans leur consentement</li>
              <li>Utiliser MAINTEX pour harceler ou intimider d&apos;autres utilisateurs</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">4. Sécurité du compte</h2>
            <p className="text-gray-600 mb-4">
              Vous êtes responsable de la sécurité de votre compte et de toutes les activités 
              effectuées avec vos identifiants. Vous devez :
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">4.1 Obligations de sécurité</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Choisir un mot de passe robuste respectant notre <Link href="/legal/mot-de-passe" className="text-[#0A0A8A] hover:underline">Politique de Mot de Passe</Link></li>
              <li>Ne pas partager vos identifiants avec qui que ce soit</li>
              <li>Ne pas réutiliser un mot de passe utilisé sur d&apos;autres services</li>
              <li>Activer l&apos;authentification à deux facteurs (2FA) lorsque disponible</li>
              <li>Nous signaler immédiatement toute utilisation non autorisée de votre compte</li>
              <li>Déconnecter votre compte sur les appareils partagés ou publics</li>
              <li>Maintenir vos informations de contact à jour pour les alertes de sécurité</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">4.2 Signalement d&apos;incident</h3>
            <p className="text-gray-600 mb-4">
              En cas de suspicion de compromission de votre compte ou de découverte d&apos;une 
              vulnérabilité, contactez immédiatement :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Incident de sécurité</strong> : <a href="mailto:security@maintex.fr" className="text-[#0A0A8A] hover:underline">security@maintex.fr</a></li>
              <li><strong>Vulnérabilité découverte</strong> : <a href="mailto:security@maintex.fr" className="text-[#0A0A8A] hover:underline">security@maintex.fr</a></li>
              <li><strong>Utilisation abusive</strong> : <a href="mailto:abuse@maintex.fr" className="text-[#0A0A8A] hover:underline">abuse@maintex.fr</a></li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">5. Contenu utilisateur</h2>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">5.1 Propriété des données</h3>
            <p className="text-gray-600 mb-4">
              Vous restez propriétaire des données et contenus que vous créez, importez ou 
              stockez dans MAINTEX. BBC & Partners ne revendique aucun droit de propriété 
              sur vos données.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">5.2 Responsabilité</h3>
            <p className="text-gray-600 mb-4">
              Vous êtes responsable des données que vous stockez dans MAINTEX. Vous vous 
              engagez à :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Ne stocker que des données dont vous êtes légitimement propriétaire ou que vous êtes autorisé à traiter</li>
              <li>Respecter les lois applicables en matière de protection des données personnelles</li>
              <li>Obtenir les consentements nécessaires pour le traitement des données de tiers</li>
              <li>Ne pas stocker de données confidentielles appartenant à des tiers sans autorisation</li>
              <li>Ne pas utiliser MAINTEX pour traiter des données sensibles nécessitant des mesures de sécurité spécifiques (données de santé, etc.) sans accord préalable</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">5.3 Modération</h3>
            <p className="text-gray-600 mb-4">
              BBC & Partners se réserve le droit, sans obligation, de :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Supprimer tout contenu illicite ou contraire à cette politique</li>
              <li>Suspendre l&apos;accès en cas de violation avérée</li>
              <li>Signaler aux autorités compétentes les contenus illicites</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">6. Utilisation de l&apos;API et intégrations</h2>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">6.1 Accès à l&apos;API</h3>
            <p className="text-gray-600 mb-4">
              L&apos;utilisation de l&apos;API MAINTEX est soumise aux conditions suivantes :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Respecter les limites de taux (rate limiting) imposées</li>
              <li>Ne pas tenter de contourner les restrictions d&apos;accès</li>
              <li>Utiliser des identifiants API dédiés et sécurisés</li>
              <li>Ne pas partager vos clés API avec des tiers</li>
              <li>Signaler tout dysfonctionnement au support technique</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">6.2 Intégrations tierces</h3>
            <p className="text-gray-600 mb-4">
              Si vous développez des intégrations avec MAINTEX :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Respecter les conditions d&apos;utilisation de l&apos;API</li>
              <li>Ne pas stocker de données d&apos;autres utilisateurs sans autorisation</li>
              <li>Implémenter des mesures de sécurité appropriées</li>
              <li>Informer vos utilisateurs des données accédées</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">7. Notifications et communications</h2>
            <p className="text-gray-600 mb-4">
              MAINTEX peut vous envoyer des notifications pour :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Les alertes système et de sécurité</li>
              <li>Les rappels d&apos;interventions planifiées</li>
              <li>Les communications relatives à votre compte</li>
              <li>Les newsletters et communications marketing (avec votre consentement)</li>
            </ul>
            <p className="text-gray-600 mb-4">
              Vous pouvez gérer vos préférences de notification dans votre profil utilisateur.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">8. Sanctions en cas de non-respect</h2>
            <p className="text-gray-600 mb-4">
              En cas de non-respect de cette politique, BBC & Partners se réserve le droit de :
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">8.1 Mesures progressives</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Avertissement</strong> : notification écrite pour les violations mineures</li>
              <li><strong>Restriction temporaire</strong> : limitation de certaines fonctionnalités</li>
              <li><strong>Suspension temporaire</strong> : blocage de l&apos;accès pendant une durée déterminée</li>
              <li><strong>Résiliation définitive</strong> : suppression du compte et de l&apos;accès</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">8.2 Cas de résiliation immédiate</h3>
            <p className="text-gray-600 mb-4">
              Certains comportements peuvent entraîner une résiliation immédiate sans avertissement :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Activités illégales avérées</li>
              <li>Atteintes graves à la sécurité</li>
              <li>Stockage de contenus illicites</li>
              <li>Usurpation d&apos;identité</li>
              <li>Harcèlement d&apos;autres utilisateurs</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">8.3 Recours judiciaires</h3>
            <p className="text-gray-600 mb-4">
              BBC & Partners se réserve le droit d&apos;engager des poursuites judiciaires en cas 
              de violation grave de cette politique ou de la législation applicable.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">9. Signalement d&apos;abus</h2>
            <p className="text-gray-600 mb-4">
              Si vous êtes témoin d&apos;une violation de cette politique ou si vous êtes victime 
              d&apos;un abus, signalez-le immédiatement :
            </p>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>Signalement d&apos;abus</strong><br />
                Email : <a href="mailto:abuse@maintex.fr" className="text-[#0A0A8A] hover:underline">abuse@maintex.fr</a><br /><br />
                <strong>Incident de sécurité</strong><br />
                Email : <a href="mailto:security@maintex.fr" className="text-[#0A0A8A] hover:underline">security@maintex.fr</a><br /><br />
                <strong>Support technique</strong><br />
                Email : <a href="mailto:support@maintex.fr" className="text-[#0A0A8A] hover:underline">support@maintex.fr</a>
              </p>
            </div>
            <p className="text-gray-600 mb-4">
              Tout signalement sera traité confidentiellement. Nous nous engageons à examiner 
              chaque signalement et à prendre les mesures appropriées.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">10. Modifications de la politique</h2>
            <p className="text-gray-600 mb-4">
              BBC & Partners se réserve le droit de modifier cette politique à tout moment. 
              Les modifications substantielles seront communiquées par notification dans 
              l&apos;application ou par email. L&apos;utilisation continue de MAINTEX après modification 
              vaut acceptation de la nouvelle politique.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">11. Contact</h2>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>BBC & Partners SAS</strong><br />
                Éditeur de MAINTEX<br /><br />
                <strong>Questions juridiques</strong><br />
                Email : <a href="mailto:legal@maintex.fr" className="text-[#0A0A8A] hover:underline">legal@maintex.fr</a><br /><br />
                <strong>Signalement d&apos;abus</strong><br />
                Email : <a href="mailto:abuse@maintex.fr" className="text-[#0A0A8A] hover:underline">abuse@maintex.fr</a><br /><br />
                <strong>Sécurité</strong><br />
                Email : <a href="mailto:security@maintex.fr" className="text-[#0A0A8A] hover:underline">security@maintex.fr</a>
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <SiteFooter />
    </main>
  )
}
