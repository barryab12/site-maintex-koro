import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import Link from 'next/link'

export default function RGPDPage() {
  return (
    <main className="min-h-screen bg-white">
      <SiteHeader />
      
      <section className="pt-[120px] pb-20 px-6 lg:px-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-[#0A0A8A] hover:underline text-sm">← Retour à l&apos;accueil</Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Conformité RGPD
          </h1>
          
          <p className="text-sm text-gray-500 mb-8">Dernière mise à jour : Janvier 2025</p>
          
          <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-8">
            <h2 className="text-lg font-semibold text-green-800 mb-2">✅ MAINTEX est conforme au RGPD</h2>
            <p className="text-green-700">
              Toutes vos données sont hébergées en France et traitées conformément au Règlement 
              Général sur la Protection des Données (RGPD). BBC & Partners s&apos;engage à protéger 
              vos données personnelles et à respecter vos droits.
            </p>
          </div>
          
          <div className="prose prose-gray max-w-none">
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">1. Introduction au RGPD</h2>
            <p className="text-gray-600 mb-4">
              Le Règlement Général sur la Protection des Données (RGPD) est le règlement européen 
              qui encadre le traitement des données personnelles. Entré en vigueur le 25 mai 2018, 
              il renforce les droits des personnes et les obligations des entreprises.
            </p>
            <p className="text-gray-600 mb-4">
              En tant qu&apos;éditeur de MAINTEX, solution de GMAO professionnelle, BBC & Partners 
              s&apos;engage pleinement à respecter ce règlement et à garantir la protection des 
              données personnelles de ses utilisateurs.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">2. Responsable de traitement</h2>
            <p className="text-gray-600 mb-4">
              BBC & Partners SAS est le responsable du traitement des données collectées via MAINTEX :
            </p>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>BBC & Partners SAS</strong><br />
                Société par Actions Simplifiée<br />
                Capital social : [Montant]<br />
                RCS [Ville] : [Numéro]<br />
                SIRET : [Numéro SIRET]<br />
                Siège social : [Adresse complète]<br /><br />
                <strong>Représentant légal</strong> : [Nom du représentant]<br />
                <strong>Contact général</strong> : <a href="mailto:contact@maintex.fr" className="text-[#0A0A8A] hover:underline">contact@maintex.fr</a>
              </p>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">3. Délégué à la Protection des Données (DPO)</h2>
            <p className="text-gray-600 mb-4">
              Conformément à l&apos;article 37 du RGPD, BBC & Partners a désigné un Délégué à la 
              Protection des Données (DPO) chargé de veiller au respect de la réglementation :
            </p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>Délégué à la Protection des Données (DPO)</strong><br />
                Email : <a href="mailto:dpo@maintex.fr" className="text-[#0A0A8A] hover:underline">dpo@maintex.fr</a><br />
                Adresse : [Adresse postale pour les demandes écrites]<br /><br />
                <em>Le DPO est votre point de contact pour toutes les questions relatives à 
                la protection de vos données personnelles et l&apos;exercice de vos droits.</em>
              </p>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">4. Hébergement et localisation des données</h2>
            <p className="text-gray-600 mb-4">
              <strong>Engagement fort :</strong> Toutes les données personnelles traitées par MAINTEX 
              sont hébergées en France métropolitaine, dans des data centers certifiés ISO 27001 
              et HDS (Hébergement de Données de Santé).
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">4.1 Localisation</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Données de production</strong> : hébergées en France (région parisienne)</li>
              <li><strong>Sauvegardes</strong> : hébergées en France (site de secours)</li>
              <li><strong>Aucun transfert hors UE</strong> : les données ne quittent jamais l&apos;Union Européenne</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">4.2 Certifications et conformité</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>ISO 27001</strong> : certification de sécurité de l&apos;information</li>
              <li><strong>HDS</strong> : certification pour l&apos;hébergement de données de santé</li>
              <li><strong>RGPD</strong> : conformité au règlement européen</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">5. Traitements de données effectués</h2>
            <p className="text-gray-600 mb-4">
              Dans le cadre de l&apos;utilisation de MAINTEX, les traitements suivants sont effectués :
            </p>
            
            <div className="overflow-x-auto mb-4">
              <table className="min-w-full border border-gray-200 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Traitement</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Finalité</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Base légale</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Conservation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 text-sm text-gray-600">
                  <tr>
                    <td className="px-4 py-3">Gestion des comptes</td>
                    <td className="px-4 py-3">Création et gestion des comptes utilisateurs</td>
                    <td className="px-4 py-3">Exécution du contrat</td>
                    <td className="px-4 py-3">Durée du contrat + 3 ans</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Authentification</td>
                    <td className="px-4 py-3">Sécurisation de l&apos;accès</td>
                    <td className="px-4 py-3">Intérêt légitime</td>
                    <td className="px-4 py-3">1 an après dernière connexion</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Gestion des interventions</td>
                    <td className="px-4 py-3">Fonctionnement de la GMAO</td>
                    <td className="px-4 py-3">Exécution du contrat</td>
                    <td className="px-4 py-3">Durée du contrat + 5 ans</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Support technique</td>
                    <td className="px-4 py-3">Assistance aux utilisateurs</td>
                    <td className="px-4 py-3">Exécution du contrat</td>
                    <td className="px-4 py-3">3 ans</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Facturation</td>
                    <td className="px-4 py-3">Gestion des abonnements</td>
                    <td className="px-4 py-3">Obligation légale</td>
                    <td className="px-4 py-3">10 ans</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Statistiques</td>
                    <td className="px-4 py-3">Amélioration du service</td>
                    <td className="px-4 py-3">Intérêt légitime</td>
                    <td className="px-4 py-3">2 ans</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Marketing</td>
                    <td className="px-4 py-3">Communications commerciales</td>
                    <td className="px-4 py-3">Consentement</td>
                    <td className="px-4 py-3">Jusqu&apos;au retrait du consentement</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">6. Vos droits RGPD</h2>
            <p className="text-gray-600 mb-4">
              Conformément aux articles 15 à 22 du RGPD, vous disposez des droits suivants 
              concernant vos données personnelles :
            </p>
            
            <div className="space-y-4 mb-4">
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Droit d&apos;accès (Article 15)</h3>
                <p className="text-gray-600">
                  Vous pouvez obtenir la confirmation que vos données sont traitées et en recevoir 
                  une copie. Vous pouvez également obtenir des informations sur les finalités, 
                  les catégories de données, les destinataires et la durée de conservation.
                </p>
              </div>
              
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Droit de rectification (Article 16)</h3>
                <p className="text-gray-600">
                  Vous pouvez faire corriger les données inexactes vous concernant ou compléter 
                  les données incomplètes. Ce droit peut être exercé directement dans votre 
                  profil utilisateur.
                </p>
              </div>
              
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Droit à l&apos;effacement (Article 17)</h3>
                <p className="text-gray-600">
                  Vous pouvez demander la suppression de vos données personnelles dans les cas 
                  suivants : données non nécessaires, retrait du consentement, opposition au 
                  traitement, traitement illicite, obligation légale d&apos;effacement.
                </p>
              </div>
              
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Droit à la limitation (Article 18)</h3>
                <p className="text-gray-600">
                  Vous pouvez demander la suspension du traitement de vos données dans certains 
                  cas : contestation de l&apos;exactitude, traitement illicite, nécessité pour la 
                  constatation de droits.
                </p>
              </div>
              
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Droit à la portabilité (Article 20)</h3>
                <p className="text-gray-600">
                  Vous pouvez recevoir vos données personnelles dans un format structuré, couramment 
                  utilisé et lisible par machine, et les transmettre à un autre responsable de 
                  traitement. Ce droit s&apos;applique aux données que vous avez fournies.
                </p>
              </div>
              
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Droit d&apos;opposition (Article 21)</h3>
                <p className="text-gray-600">
                  Vous pouvez vous opposer au traitement de vos données fondé sur l&apos;intérêt 
                  légitime. Pour les traitements fondés sur le consentement, vous pouvez le 
                  retirer à tout moment.
                </p>
              </div>
              
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Droit de ne pas faire l&apos;objet d&apos;une décision automatisée (Article 22)</h3>
                <p className="text-gray-600">
                  Vous avez le droit de ne pas faire l&apos;objet d&apos;une décision fondée exclusivement 
                  sur un traitement automatisé produisant des effets juridiques ou affectant 
                  significativement votre situation.
                </p>
              </div>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">7. Comment exercer vos droits</h2>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">7.1 Par email</h3>
            <p className="text-gray-600 mb-4">
              Envoyez votre demande à notre DPO : <a href="mailto:dpo@maintex.fr" className="text-[#0A0A8A] hover:underline">dpo@maintex.fr</a>
            </p>
            <p className="text-gray-600 mb-4">
              Pour faciliter le traitement de votre demande, veuillez préciser :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Votre identité (nom, prénom, email utilisé sur MAINTEX)</li>
              <li>Le droit que vous souhaitez exercer</li>
              <li>Les données concernées si applicable</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">7.2 Par courrier postal</h3>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4">
              <p className="text-gray-700">
                <strong>BBC & Partners SAS - DPO</strong><br />
                [Adresse postale]<br />
                [Code postal - Ville]
              </p>
            </div>
            <p className="text-gray-600 mb-4">
              Joignez une copie de votre pièce d&apos;identité pour vérification.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">7.3 Délais de réponse</h3>
            <p className="text-gray-600 mb-4">
              Nous nous engageons à répondre à votre demande dans un délai d&apos;un mois à compter 
              de la réception. Ce délai peut être prolongé de deux mois supplémentaires en cas 
              de demande complexe. Vous serez informé de cette prolongation et des motifs dans 
              un délai d&apos;un mois.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">7.4 Export de vos données</h3>
            <p className="text-gray-600 mb-4">
              Vous pouvez exporter vos données directement depuis MAINTEX :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Connectez-vous à votre compte</li>
              <li>Accédez à <strong>Paramètres &gt; Données &gt; Exporter mes données</strong></li>
              <li>Sélectionnez le format (JSON, CSV)</li>
              <li>Vous recevrez un lien de téléchargement par email</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">8. Réclamation auprès de la CNIL</h2>
            <p className="text-gray-600 mb-4">
              Si vous estimez que le traitement de vos données personnelles n&apos;est pas conforme 
              à la réglementation, vous avez le droit d&apos;introduire une réclamation auprès de 
              la Commission Nationale de l&apos;Informatique et des Libertés (CNIL) :
            </p>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>Commission Nationale de l&apos;Informatique et des Libertés (CNIL)</strong><br />
                3 Place de Fontenoy<br />
                TSA 80715<br />
                75334 Paris Cedex 07<br /><br />
                <strong>Téléphone</strong> : 01 53 73 22 22<br />
                <strong>Site web</strong> : <a href="https://www.cnil.fr" target="_blank" rel="noopener noreferrer" className="text-[#0A0A8A] hover:underline">www.cnil.fr</a><br />
                <strong>Réclamation en ligne</strong> : <a href="https://www.cnil.fr/fr/plaintes" target="_blank" rel="noopener noreferrer" className="text-[#0A0A8A] hover:underline">www.cnil.fr/fr/plaintes</a>
              </p>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">9. Sous-traitants</h2>
            <p className="text-gray-600 mb-4">
              BBC & Partners fait appel à des sous-traitants pour certains services. Tous ont 
              signé des clauses de confidentialité et sont conformes au RGPD :
            </p>
            
            <div className="overflow-x-auto mb-4">
              <table className="min-w-full border border-gray-200 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Sous-traitant</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Pays</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Traitement</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 text-sm text-gray-600">
                  <tr>
                    <td className="px-4 py-3">Hébergeur certifié ISO 27001</td>
                    <td className="px-4 py-3">France</td>
                    <td className="px-4 py-3">Hébergement des données</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Prestataire de paiement</td>
                    <td className="px-4 py-3">France / UE</td>
                    <td className="px-4 py-3">Paiements sécurisés</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Service de messagerie</td>
                    <td className="px-4 py-3">France / UE</td>
                    <td className="px-4 py-3">Emails transactionnels</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Outil de support</td>
                    <td className="px-4 py-3">UE</td>
                    <td className="px-4 py-3">Support client</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">10. Registre des traitements</h2>
            <p className="text-gray-600 mb-4">
              Conformément à l&apos;article 30 du RGPD, BBC & Partners tient un registre des activités 
              de traitement qui recense l&apos;ensemble des traitements de données personnelles effectués. 
              Ce registre documente :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Le nom et les coordonnées du responsable de traitement</li>
              <li>Les finalités du traitement</li>
              <li>Les catégories de personnes concernées et de données</li>
              <li>Les catégories de destinataires</li>
              <li>Les transferts de données vers des pays tiers</li>
              <li>Les délais de conservation</li>
              <li>Les mesures de sécurité techniques et organisationnelles</li>
            </ul>
            <p className="text-gray-600 mb-4">
              Ce registre peut être communiqué sur demande motivée à notre DPO.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">11. Sécurité des données</h2>
            <p className="text-gray-600 mb-4">
              BBC & Partners met en œuvre des mesures techniques et organisationnelles appropriées 
              pour garantir un niveau de sécurité adapté aux risques :
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">11.1 Mesures techniques</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Chiffrement</strong> : TLS 1.3 pour les communications, chiffrement au repos (AES-256)</li>
              <li><strong>Authentification</strong> : politique de mots de passe robuste, authentification à deux facteurs</li>
              <li><strong>Contrôle d&apos;accès</strong> : gestion des droits par rôle, principe du moindre privilège</li>
              <li><strong>Journalisation</strong> : traçabilité des accès et des opérations sensibles</li>
              <li><strong>Sauvegardes</strong> : sauvegardes quotidiennes chiffrées avec tests de restauration réguliers</li>
              <li><strong>Monitoring</strong> : surveillance en temps réel des systèmes et alertes automatiques</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">11.2 Mesures organisationnelles</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Politique de sécurité</strong> : documentée et communiquée à tous les collaborateurs</li>
              <li><strong>Formation</strong> : sensibilisation régulière à la protection des données</li>
              <li><strong>Confidentialité</strong> : clauses de confidentialité dans les contrats de travail</li>
              <li><strong>Procédures</strong> : gestion des incidents, des demandes de droits et des violations</li>
              <li><strong>Audits</strong> : audits réguliers et tests de pénétration</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">11.3 Notification des violations</h3>
            <p className="text-gray-600 mb-4">
              En cas de violation de données personnelles :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Notification à la CNIL</strong> : dans les 72 heures suivant la constatation (art. 33 RGPD)</li>
              <li><strong>Notification aux personnes concernées</strong> : sans délai excessif si risque élevé pour leurs droits (art. 34 RGPD)</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">12. Évaluation d&apos;impact (PIA)</h2>
            <p className="text-gray-600 mb-4">
              Lorsqu&apos;un traitement est susceptible d&apos;engendrer un risque élevé pour les droits 
              et libertés des personnes, BBC & Partners réalise une Analyse d&apos;Impact relative 
              à la Protection des Données (AIPD ou PIA) conformément à l&apos;article 35 du RGPD.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">13. Documentation associée</h2>
            <p className="text-gray-600 mb-4">
              Pour plus d&apos;informations, consultez nos autres documents juridiques :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><Link href="/legal/cgu" className="text-[#0A0A8A] hover:underline">Conditions Générales d&apos;Utilisation</Link></li>
              <li><Link href="/legal/confidentialite" className="text-[#0A0A8A] hover:underline">Politique de Confidentialité</Link></li>
              <li><Link href="/legal/cookies" className="text-[#0A0A8A] hover:underline">Politique Relative aux Cookies</Link></li>
              <li><Link href="/legal/mot-de-passe" className="text-[#0A0A8A] hover:underline">Politique de Mot de Passe</Link></li>
              <li><Link href="/legal/utilisation-acceptable" className="text-[#0A0A8A] hover:underline">Politique d&apos;Utilisation Acceptable</Link></li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">14. Mise à jour</h2>
            <p className="text-gray-600 mb-4">
              Cette page de conformité RGPD peut être mise à jour périodiquement pour refléter 
              les évolutions réglementaires ou nos pratiques. La date de dernière mise à jour 
              est indiquée en tête de ce document.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">15. Contact</h2>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>Pour toute question relative à la protection des données</strong><br /><br />
                <strong>Délégué à la Protection des Données (DPO)</strong><br />
                Email : <a href="mailto:dpo@maintex.fr" className="text-[#0A0A8A] hover:underline">dpo@maintex.fr</a><br /><br />
                <strong>BBC & Partners SAS</strong><br />
                Éditeur de MAINTEX<br />
                Email : <a href="mailto:contact@maintex.fr" className="text-[#0A0A8A] hover:underline">contact@maintex.fr</a>
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <SiteFooter />
    </main>
  )
}
