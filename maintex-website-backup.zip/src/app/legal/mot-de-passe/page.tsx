import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import Link from 'next/link'

export default function MotDePassePage() {
  return (
    <main className="min-h-screen bg-white">
      <SiteHeader />
      
      <section className="pt-[120px] pb-20 px-6 lg:px-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-[#0A0A8A] hover:underline text-sm">← Retour à l&apos;accueil</Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Politique de Mot de Passe
          </h1>
          
          <p className="text-sm text-gray-500 mb-8">Dernière mise à jour : Janvier 2025</p>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 mb-8">
            <p className="text-yellow-800">
              <strong>Sécurité de votre compte</strong><br />
              La sécurité de vos données de GMAO est une priorité pour MAINTEX. Cette politique 
              définit les exigences et bonnes pratiques en matière de mots de passe pour protéger 
              votre compte et les données de votre organisation.
            </p>
          </div>
          
          <div className="prose prose-gray max-w-none">
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">1. Objectif</h2>
            <p className="text-gray-600 mb-4">
              La présente politique de mot de passe a pour objectif de garantir un niveau de sécurité 
              optimal pour les comptes utilisateurs de MAINTEX. Elle s&apos;applique à tous les utilisateurs 
              de la plateforme, quel que soit leur rôle (administrateur, technicien, gestionnaire, etc.).
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">2. Exigences de complexité</h2>
            <p className="text-gray-600 mb-4">
              Pour créer un mot de passe sécurisé sur MAINTEX, les règles suivantes sont obligatoires :
            </p>
            
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <h3 className="font-semibold text-gray-900 mb-4">Règles obligatoires</h3>
              <ul className="text-gray-600 space-y-2">
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span><strong>Longueur minimale</strong> : 12 caractères minimum</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span><strong>Majuscules</strong> : au moins 1 lettre majuscule (A-Z)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span><strong>Minuscules</strong> : au moins 1 lettre minuscule (a-z)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span><strong>Chiffres</strong> : au moins 1 chiffre (0-9)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span><strong>Caractères spéciaux</strong> : au moins 1 caractère spécial (!@#$%^&*()_+-=[]{}|;:&apos;&quot;,./&lt;&gt;?)</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-4">
              <h3 className="font-semibold text-red-800 mb-4">Restrictions</h3>
              <ul className="text-red-700 space-y-2">
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>Le mot de passe ne doit pas contenir votre nom, prénom ou email</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>Le mot de passe ne doit pas être identique aux 10 précédents mots de passe</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>Le mot de passe ne doit pas figurer dans les listes de mots de passe compromises connues</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>Les séquences évidentes sont interdites (123456, abcdef, azerty, password, etc.)</span>
                </li>
              </ul>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">3. Durée de validité et renouvellement</h2>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.1 Renouvellement périodique</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Utilisateurs standard</strong> : renouvellement recommandé tous les 12 mois</li>
              <li><strong>Administrateurs</strong> : renouvellement obligatoire tous les 6 mois</li>
              <li><strong>Accès sensible</strong> : renouvellement obligatoire tous les 3 mois</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">3.2 Notification d&apos;expiration</h3>
            <p className="text-gray-600 mb-4">
              Un email de rappel vous est envoyé automatiquement :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>14 jours avant l&apos;expiration de votre mot de passe</li>
              <li>7 jours avant l&apos;expiration</li>
              <li>Le jour de l&apos;expiration</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">4. Procédure de réinitialisation</h2>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">4.1 Réinitialisation par l&apos;utilisateur</h3>
            <p className="text-gray-600 mb-4">
              Si vous avez oublié votre mot de passe, procédez comme suit :
            </p>
            <ol className="list-decimal pl-6 text-gray-600 mb-4 space-y-2">
              <li>Sur la page de connexion, cliquez sur <strong>&quot;Mot de passe oublié&quot;</strong></li>
              <li>Entrez votre adresse email professionnelle</li>
              <li>Vous recevrez un email avec un lien de réinitialisation sécurisé</li>
              <li>Le lien est valide pendant <strong>24 heures</strong></li>
              <li>Cliquez sur le lien et créez un nouveau mot de passe respectant les exigences</li>
              <li>Vous serez automatiquement déconnecté de toutes les autres sessions</li>
            </ol>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">4.2 Réinitialisation par un administrateur</h3>
            <p className="text-gray-600 mb-4">
              Les administrateurs de votre organisation peuvent réinitialiser votre mot de passe. 
              Dans ce cas :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Un email de réinitialisation vous est envoyé automatiquement</li>
              <li>Vous devrez créer un nouveau mot de passe à la prochaine connexion</li>
              <li>L&apos;administrateur ne peut pas voir ou définir votre mot de passe</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">4.3 Réinitialisation par le support</h3>
            <p className="text-gray-600 mb-4">
              En cas de problème avec la réinitialisation automatique, contactez le support à 
              <a href="mailto:support@maintex.fr" className="text-[#0A0A8A] hover:underline"> support@maintex.fr</a>. 
              Un agent pourra vous envoyer un nouveau lien de réinitialisation après vérification de votre identité.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">5. Verrouillage de compte</h2>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">5.1 Tentatives échouées</h3>
            <p className="text-gray-600 mb-4">
              Pour protéger votre compte contre les attaques par force brute :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Après <strong>5 tentatives échouées</strong>, le compte est temporairement verrouillé pendant 15 minutes</li>
              <li>Après <strong>10 tentatives échouées</strong>, le compte est verrouillé pendant 1 heure</li>
              <li>Après <strong>15 tentatives échouées</strong>, le compte est verrouillé jusqu&apos;à réinitialisation du mot de passe</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">5.2 Déblocage du compte</h3>
            <p className="text-gray-600 mb-4">
              Pour débloquer votre compte après verrouillage :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li>Attendez la fin de la période de verrouillage temporaire</li>
              <li>Ou utilisez la procédure de réinitialisation de mot de passe</li>
              <li>Ou contactez un administrateur de votre organisation</li>
              <li>Ou contactez le support à <a href="mailto:support@maintex.fr" className="text-[#0A0A8A] hover:underline">support@maintex.fr</a></li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">6. Authentification à deux facteurs (2FA)</h2>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">6.1 Principe</h3>
            <p className="text-gray-600 mb-4">
              L&apos;authentification à deux facteurs ajoute une couche de sécurité supplémentaire en 
              demandant un second moyen d&apos;authentification en plus de votre mot de passe.
            </p>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">6.2 Méthodes disponibles</h3>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Application d&apos;authentification</strong> : Google Authenticator, Microsoft Authenticator, Authy, etc. (recommandé)</li>
              <li><strong>SMS</strong> : code envoyé par SMS sur votre téléphone mobile</li>
              <li><strong>Email</strong> : code envoyé sur votre email secondaire</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">6.3 Configuration obligatoire</h3>
            <p className="text-gray-600 mb-4">
              L&apos;activation de la 2FA est :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Recommandée</strong> pour tous les utilisateurs</li>
              <li><strong>Obligatoire</strong> pour les administrateurs et les utilisateurs avec accès aux données sensibles</li>
              <li><strong>Obligatoire</strong> si votre organisation a activé cette politique</li>
            </ul>
            
            <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-3">6.4 Codes de récupération</h3>
            <p className="text-gray-600 mb-4">
              Lors de l&apos;activation de la 2FA, vous recevrez des codes de récupération à conserver 
              précieusement. Ces codes vous permettent d&apos;accéder à votre compte si vous perdez 
              l&apos;accès à votre méthode 2FA habituelle.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">7. Recommandations de sécurité</h2>
            
            <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-4">
              <h3 className="font-semibold text-green-800 mb-4">Bonnes pratiques</h3>
              <ul className="text-green-700 space-y-2">
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span>Utilisez un gestionnaire de mots de passe pour générer et stocker vos mots de passe</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span>Créez un mot de passe unique pour MAINTEX, différent de vos autres comptes</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span>Ne partagez jamais votre mot de passe, même avec vos collègues</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span>Ne notez pas votre mot de passe sur un post-it ou dans un fichier non sécurisé</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span>Changez immédiatement votre mot de passe si vous soupçonnez une compromission</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span>Activez l&apos;authentification à deux facteurs (2FA)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span>Vérifiez régulièrement les connexions actives dans votre profil</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-500 mt-1">✓</span>
                  <span>Déconnectez-vous sur les ordinateurs partagés ou publics</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-4">
              <h3 className="font-semibold text-red-800 mb-4">À éviter absolument</h3>
              <ul className="text-red-700 space-y-2">
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>Les mots de passe basés sur des informations personnelles (date de naissance, nom du chien...)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>Les mots de passe simples comme &quot;Password123!&quot; ou &quot;Maintex2024&quot;</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>Le partage de comptes entre utilisateurs</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>L&apos;envoi de mots de passe par email ou messagerie non chiffrée</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>La réutilisation du même mot de passe sur plusieurs sites</span>
                </li>
              </ul>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">8. Gestionnaires de mots de passe recommandés</h2>
            <p className="text-gray-600 mb-4">
              Pour vous aider à gérer vos mots de passe de manière sécurisée, nous recommandons 
              l&apos;utilisation d&apos;un gestionnaire de mots de passe :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>1Password</strong> - Solution professionnelle avec partage d&apos;équipe</li>
              <li><strong>Bitwarden</strong> - Open source et gratuit pour l&apos;usage personnel</li>
              <li><strong>Dashlane</strong> - Interface intuitive avec fonctionnalités avancées</li>
              <li><strong>LastPass</strong> - Populaire avec plan gratuit disponible</li>
              <li><strong>KeePass</strong> - Open source et gratuit, stockage local</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">9. En cas de compromission suspectée</h2>
            <p className="text-gray-600 mb-4">
              Si vous pensez que votre mot de passe a été compromis ou si vous remarquez une 
              activité suspecte sur votre compte :
            </p>
            <ol className="list-decimal pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Changez immédiatement votre mot de passe</strong> depuis votre profil</li>
              <li><strong>Déconnectez toutes les sessions</strong> actives (disponible dans votre profil)</li>
              <li><strong>Activez la 2FA</strong> si ce n&apos;est pas déjà fait</li>
              <li><strong>Vérifiez vos informations personnelles</strong> (email de récupération, téléphone)</li>
              <li><strong>Contactez immédiatement le support</strong> à <a href="mailto:security@maintex.fr" className="text-[#0A0A8A] hover:underline">security@maintex.fr</a></li>
              <li><strong>Informez votre administrateur</strong> si vous êtes dans un contexte organisationnel</li>
            </ol>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">10. Responsabilités</h2>
            <p className="text-gray-600 mb-4">
              <strong>Utilisateur</strong> : Vous êtes responsable de la confidentialité de votre mot de passe 
              et de toute activité effectuée avec votre compte.
            </p>
            <p className="text-gray-600 mb-4">
              <strong>Organisation</strong> : Les administrateurs de votre organisation sont responsables de 
              l&apos;application de cette politique et de la gestion des accès utilisateurs.
            </p>
            <p className="text-gray-600 mb-4">
              <strong>BBC & Partners</strong> : Nous nous engageons à sécuriser les mots de passe par hachage 
              irréversible (bcrypt) et à protéger les accès conformément aux standards de l&apos;industrie.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">11. Contact</h2>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>Pour les questions de sécurité</strong><br />
                Email : <a href="mailto:security@maintex.fr" className="text-[#0A0A8A] hover:underline">security@maintex.fr</a><br /><br />
                <strong>Pour le support technique</strong><br />
                Email : <a href="mailto:support@maintex.fr" className="text-[#0A0A8A] hover:underline">support@maintex.fr</a><br />
                Téléphone : <a href="tel:+33182000000" className="text-[#0A0A8A] hover:underline">+33 1 82 00 00 00</a><br /><br />
                <strong>Pour la protection des données</strong><br />
                DPO : <a href="mailto:dpo@maintex.fr" className="text-[#0A0A8A] hover:underline">dpo@maintex.fr</a>
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <SiteFooter />
    </main>
  )
}
