import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import Link from 'next/link'

export default function SupportPage() {
  return (
    <main className="min-h-screen bg-white">
      <SiteHeader />
      
      <section className="pt-[120px] pb-20 px-6 lg:px-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-[#0A0A8A] hover:underline text-sm">← Retour à l&apos;accueil</Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Politique de Support
          </h1>
          
          <p className="text-sm text-gray-500 mb-8">Dernière mise à jour : Janvier 2025</p>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-2">Centre de Support MAINTEX</h2>
            <p className="text-gray-600">
              Notre équipe support est dédiée à vous accompagner dans l&apos;utilisation de votre 
              solution de GMAO. Nous nous engageons à vous fournir une assistance réactive et 
              de qualité pour garantir le bon fonctionnement de vos opérations de maintenance.
            </p>
          </div>
          
          <div className="prose prose-gray max-w-none">
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">1. Canaux de contact</h2>
            
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-2xl">📧</span>
                  <h3 className="text-lg font-semibold text-gray-900">Email</h3>
                </div>
                <p className="text-gray-600 mb-2">Pour toutes demandes et questions</p>
                <a href="mailto:support@maintex.fr" className="text-[#0A0A8A] font-medium hover:underline text-lg">
                  support@maintex.fr
                </a>
                <p className="text-sm text-gray-500 mt-2">Réponse sous 4h ouvrées</p>
              </div>
              
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-2xl">📞</span>
                  <h3 className="text-lg font-semibold text-gray-900">Téléphone</h3>
                </div>
                <p className="text-gray-600 mb-2">Pour les urgences et assistance directe</p>
                <a href="tel:+33182000000" className="text-[#0A0A8A] font-medium hover:underline text-lg">
                  +33 1 82 00 00 00
                </a>
                <p className="text-sm text-gray-500 mt-2">Lun-Ven, 9h-18h (heure de Paris)</p>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-2xl">💬</span>
                  <h3 className="text-lg font-semibold text-gray-900">Chat en ligne</h3>
                </div>
                <p className="text-gray-600 mb-2">Directement dans l&apos;application MAINTEX</p>
                <p className="text-[#0A0A8A] font-medium">Disponible 9h-18h</p>
                <p className="text-sm text-gray-500 mt-2">Réponse immédiate</p>
              </div>
              
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-2xl">📚</span>
                  <h3 className="text-lg font-semibold text-gray-900">Base de connaissances</h3>
                </div>
                <p className="text-gray-600 mb-2">Tutoriels et guides d&apos;utilisation</p>
                <a href="#" className="text-[#0A0A8A] font-medium hover:underline">help.maintex.fr</a>
                <p className="text-sm text-gray-500 mt-2">Accès 24h/24, 7j/7</p>
              </div>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">2. Horaires d&apos;ouverture</h2>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Support standard</h3>
                  <ul className="text-gray-600 space-y-1">
                    <li>• Lundi au vendredi : 9h00 - 18h00</li>
                    <li>• Heure de Paris (CET/CEST)</li>
                    <li>• Fermé les jours fériés français</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Support urgence (Critique)</h3>
                  <ul className="text-gray-600 space-y-1">
                    <li>• 24h/24, 7j/7</li>
                    <li>• Uniquement pour les incidents critiques</li>
                    <li>• +33 1 82 00 00 01</li>
                  </ul>
                </div>
              </div>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">3. Niveaux de priorité</h2>
            <p className="text-gray-600 mb-4">
              Pour garantir un traitement efficace de vos demandes, nous classons les incidents 
              selon 4 niveaux de priorité :
            </p>
            
            <div className="overflow-x-auto mb-4">
              <table className="min-w-full border border-gray-200 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Niveau</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Définition</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Exemple</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">Temps de réponse</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  <tr className="bg-red-50">
                    <td className="px-4 py-3 text-sm font-medium text-red-700">Critique (P1)</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Service totalement indisponible</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Impossible de se connecter, perte de données</td>
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">1 heure</td>
                  </tr>
                  <tr className="bg-orange-50">
                    <td className="px-4 py-3 text-sm font-medium text-orange-700">Élevé (P2)</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Fonctionnalité majeure indisponible</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Impossible de créer des interventions</td>
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">4 heures</td>
                  </tr>
                  <tr className="bg-yellow-50">
                    <td className="px-4 py-3 text-sm font-medium text-yellow-700">Moyen (P3)</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Fonctionnalité partiellement impactée</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Lenteur, erreur d&apos;affichage</td>
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">8 heures</td>
                  </tr>
                  <tr className="bg-green-50">
                    <td className="px-4 py-3 text-sm font-medium text-green-700">Faible (P4)</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Question, demande d&apos;amélioration</td>
                    <td className="px-4 py-3 text-sm text-gray-600">Comment utiliser une fonctionnalité</td>
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">24 heures</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">4. Engagement de niveau de service (SLA)</h2>
            <p className="text-gray-600 mb-4">
              BBC & Partners s&apos;engage sur les indicateurs de qualité suivants pour MAINTEX :
            </p>
            
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <h3 className="font-semibold text-gray-900 mb-4">Disponibilité de la plateforme</h3>
              <ul className="text-gray-600 space-y-2">
                <li>• <strong>Taux de disponibilité</strong> : 99,5% mensuel (hors maintenance programmée)</li>
                <li>• <strong>Maintenance programmée</strong> : communiquée 48h à l&apos;avance, effectuée de préférence le week-end</li>
                <li>• <strong>Sauvegardes</strong> : quotidiennes, avec RPO (Recovery Point Objective) de 24h maximum</li>
                <li>• <strong>Temps de récupération (RTO)</strong> : 4 heures maximum en cas d&apos;incident majeur</li>
              </ul>
            </div>
            
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <h3 className="font-semibold text-gray-900 mb-4">Temps de traitement des demandes</h3>
              <ul className="text-gray-600 space-y-2">
                <li>• <strong>Accusé de réception</strong> : immédiat (automatique par email)</li>
                <li>• <strong>Première réponse</strong> : selon le niveau de priorité (voir tableau ci-dessus)</li>
                <li>• <strong>Résolution</strong> : engagement sur les meilleurs efforts selon la complexité</li>
                <li>• <strong>Suivi</strong> : mise à jour régulière du statut de la demande</li>
              </ul>
            </div>
            
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <h3 className="font-semibold text-gray-900 mb-4">Compensation en cas de non-respect du SLA</h3>
              <p className="text-gray-600 mb-2">
                En cas de non-respect des engagements de disponibilité (en-deçà de 99,5% sur un mois), 
                un avoir sera crédité sur votre prochaine facture :
              </p>
              <ul className="text-gray-600 space-y-1">
                <li>• 99% à 99,5% de disponibilité : avoir de 5% de l&apos;abonnement mensuel</li>
                <li>• 95% à 99% de disponibilité : avoir de 10% de l&apos;abonnement mensuel</li>
                <li>• Moins de 95% de disponibilité : avoir de 25% de l&apos;abonnement mensuel</li>
              </ul>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">5. Processus de gestion des demandes</h2>
            <ol className="list-decimal pl-6 text-gray-600 mb-4 space-y-3">
              <li><strong>Soumission</strong> : vous créez une demande via email, téléphone ou chat</li>
              <li><strong>Tri et qualification</strong> : notre équipe analyse et priorise votre demande</li>
              <li><strong>Assignation</strong> : un technicien est désigné pour traiter votre demande</li>
              <li><strong>Diagnostic</strong> : analyse du problème et identification de la solution</li>
              <li><strong>Résolution</strong> : mise en œuvre de la correction ou de la solution</li>
              <li><strong>Validation</strong> : confirmation de la résolution avec l&apos;utilisateur</li>
              <li><strong>Clôture</strong> : fermeture du ticket et enquête de satisfaction</li>
            </ol>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">6. Formation et accompagnement</h2>
            <p className="text-gray-600 mb-4">
              BBC & Partners propose des services de formation pour optimiser votre utilisation de MAINTEX :
            </p>
            <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
              <li><strong>Formation initiale</strong> : session de démarrage incluse dans l&apos;abonnement (2h en visio)</li>
              <li><strong>Formations avancées</strong> : sessions personnalisées sur les modules spécifiques (sur devis)</li>
              <li><strong>Webinaires mensuels</strong> : présentation des nouvelles fonctionnalités (gratuits)</li>
              <li><strong>Documentation en ligne</strong> : guides, tutoriels et FAQ accessibles 24h/24</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">7. Foire aux questions (FAQ)</h2>
            
            <div className="space-y-4 mb-8">
              <details className="bg-gray-50 border border-gray-200 rounded-xl p-6 cursor-pointer">
                <summary className="font-semibold text-gray-900">Comment réinitialiser mon mot de passe ?</summary>
                <p className="text-gray-600 mt-4">
                  Cliquez sur &quot;Mot de passe oublié&quot; sur la page de connexion. Vous recevrez un email 
                  avec un lien de réinitialisation valide pendant 24 heures. Si vous ne recevez pas 
                  l&apos;email, vérifiez vos spams ou contactez le support.
                </p>
              </details>
              
              <details className="bg-gray-50 border border-gray-200 rounded-xl p-6 cursor-pointer">
                <summary className="font-semibold text-gray-900">Comment ajouter un nouvel utilisateur ?</summary>
                <p className="text-gray-600 mt-4">
                  Accédez à <strong>Paramètres &gt; Utilisateurs &gt; Ajouter</strong>. Entrez l&apos;email du nouvel 
                  utilisateur et définissez son rôle. Il recevra une invitation pour créer son compte 
                  et rejoindre votre organisation.
                </p>
              </details>
              
              <details className="bg-gray-50 border border-gray-200 rounded-xl p-6 cursor-pointer">
                <summary className="font-semibold text-gray-900">L&apos;application mobile est-elle disponible ?</summary>
                <p className="text-gray-600 mt-4">
                  Oui, MAINTEX est disponible sur iOS (App Store) et Android (Google Play). 
                  Téléchargez l&apos;application et connectez-vous avec vos identifiants habituels. 
                  L&apos;application mobile permet aux techniciens de saisir leurs interventions sur le terrain.
                </p>
              </details>
              
              <details className="bg-gray-50 border border-gray-200 rounded-xl p-6 cursor-pointer">
                <summary className="font-semibold text-gray-900">Comment exporter mes données ?</summary>
                <p className="text-gray-600 mt-4">
                  Accédez à <strong>Paramètres &gt; Données &gt; Exporter</strong>. Vous pouvez exporter vos 
                  données au format CSV ou Excel (XLSX). L&apos;export peut prendre quelques minutes 
                  selon le volume de données. Vous serez notifié par email dès que l&apos;export sera prêt.
                </p>
              </details>
              
              <details className="bg-gray-50 border border-gray-200 rounded-xl p-6 cursor-pointer">
                <summary className="font-semibold text-gray-900">Quels sont les navigateurs supportés ?</summary>
                <p className="text-gray-600 mt-4">
                  MAINTEX est compatible avec les dernières versions de Chrome, Firefox, Safari et Edge. 
                  Nous recommandons Chrome pour une expérience optimale. Internet Explorer n&apos;est pas supporté.
                </p>
              </details>
              
              <details className="bg-gray-50 border border-gray-200 rounded-xl p-6 cursor-pointer">
                <summary className="font-semibold text-gray-900">Comment fonctionne la facturation ?</summary>
                <p className="text-gray-600 mt-4">
                  La facturation est mensuelle ou annuelle selon votre abonnement. Vous recevez 
                  vos factures par email et pouvez les retrouver dans <strong>Paramètres &gt; Facturation</strong>. 
                  Le paiement s&apos;effectue par prélèvement automatique ou virement.
                </p>
              </details>
              
              <details className="bg-gray-50 border border-gray-200 rounded-xl p-6 cursor-pointer">
                <summary className="font-semibold text-gray-900">Puis-je personnaliser les champs et les formulaires ?</summary>
                <p className="text-gray-600 mt-4">
                  Oui, MAINTEX permet de créer des champs personnalisés pour les équipements, 
                  interventions et autres entités. Accédez à <strong>Paramètres &gt; Champs personnalisés</strong> 
                  pour configurer vos formulaires selon vos besoins métier.
                </p>
              </details>
              
              <details className="bg-gray-50 border border-gray-200 rounded-xl p-6 cursor-pointer">
                <summary className="font-semibold text-gray-900">Comment signaler un bug ou suggérer une amélioration ?</summary>
                <p className="text-gray-600 mt-4">
                  Envoyez-nous vos retours par email à <a href="mailto:feedback@maintex.fr" className="text-[#0A0A8A] hover:underline">feedback@maintex.fr</a> ou 
                  utilisez le formulaire dans <strong>Aide &gt; Envoyer un feedback</strong>. Chaque suggestion 
                  est étudiée par notre équipe produit.
                </p>
              </details>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">8. Statut des services</h2>
            <p className="text-gray-600 mb-4">
              Consultez en temps réel l&apos;état de nos services et les incidents en cours sur notre 
              page de statut : <a href="#" className="text-[#0A0A8A] hover:underline">status.maintex.fr</a>
            </p>
            <p className="text-gray-600 mb-4">
              Vous pouvez vous abonner aux notifications pour être informé en temps réel des 
              incidents et maintenances programmées.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-900 mt-8 mb-4">9. Contact</h2>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <p className="text-gray-700">
                <strong>Équipe Support MAINTEX</strong><br /><br />
                <strong>Email :</strong> <a href="mailto:support@maintex.fr" className="text-[#0A0A8A] hover:underline">support@maintex.fr</a><br />
                <strong>Téléphone :</strong> <a href="tel:+33182000000" className="text-[#0A0A8A] hover:underline">+33 1 82 00 00 00</a><br />
                <strong>Chat :</strong> Disponible dans l&apos;application<br /><br />
                <strong>Horaires :</strong> Lundi au vendredi, 9h-18h (heure de Paris)<br />
                <strong>Urgences 24/7 :</strong> +33 1 82 00 00 01 (incidents critiques uniquement)
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <SiteFooter />
    </main>
  )
}
