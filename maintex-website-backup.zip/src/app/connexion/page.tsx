'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Eye, EyeOff, LogIn, Mail, Lock, ArrowRight, Shield, Clock, Users, CheckCircle2 } from 'lucide-react'

export default function ConnexionPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    // Simulation de connexion
    setTimeout(() => {
      setIsLoading(false)
      alert('Connexion réussie !')
    }, 1500)
  }

  return (
    <main className="min-h-screen bg-white flex">
      {/* Left Side - Form */}
      <div className="flex-1 flex flex-col justify-center px-8 lg:px-16 xl:px-24">
        <div className="max-w-md w-full mx-auto">
          {/* Logo */}
          <Link href="/" className="inline-block mb-10">
            <img
              src="/upload/logo-maintex.png"
              alt="MAINTEX"
              className="h-10"
            />
          </Link>

          {/* Title */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Bienvenue
            </h1>
            <p className="text-gray-500">
              Connectez-vous à votre espace MAINTEX
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Adresse email professionnelle
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full pl-12 pr-4 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0A0A8A] focus:border-transparent outline-none transition-all text-gray-900 bg-gray-50 focus:bg-white"
                  placeholder="vous@entreprise.com"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  Mot de passe
                </label>
                <Link href="/legal/mot-de-passe" className="text-sm text-[#0A0A8A] hover:underline font-medium">
                  Mot de passe oublié ?
                </Link>
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full pl-12 pr-12 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0A0A8A] focus:border-transparent outline-none transition-all text-gray-900 bg-gray-50 focus:bg-white"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded border-gray-300 text-[#0A0A8A] focus:ring-[#0A0A8A]" 
                />
                <span className="text-sm text-gray-600">Se souvenir de moi</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-4 px-6 bg-[#0A0A8A] text-white font-semibold rounded-xl hover:bg-[#0A0A8A]/90 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-[#0A0A8A]/20"
            >
              {isLoading ? (
                <span className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
              ) : (
                <>
                  <LogIn className="w-5 h-5" />
                  Se connecter
                </>
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-200" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-4 bg-white text-gray-500">Nouveau sur MAINTEX ?</span>
            </div>
          </div>

          {/* Sign Up Link */}
          <Link
            href="/inscription"
            className="w-full py-4 px-6 border-2 border-gray-200 text-gray-700 font-semibold rounded-xl hover:border-[#0A0A8A] hover:text-[#0A0A8A] transition-all flex items-center justify-center gap-2"
          >
            Créer un compte gratuit
            <ArrowRight className="w-5 h-5" />
          </Link>

          {/* Legal */}
          <p className="mt-8 text-center text-xs text-gray-400">
            En vous connectant, vous acceptez nos{' '}
            <Link href="/legal/cgu" className="text-[#0A0A8A] hover:underline">
              Conditions d&apos;utilisation
            </Link>
            {' '}et notre{' '}
            <Link href="/legal/confidentialite" className="text-[#0A0A8A] hover:underline">
              Politique de confidentialité
            </Link>
          </p>
        </div>
      </div>

      {/* Right Side - Branding */}
      <div className="hidden lg:flex lg:flex-1 bg-gradient-to-br from-[#0A0A8A] via-[#0A0A8A] to-[#050560] relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-72 h-72 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 flex flex-col justify-center px-16 xl:px-24 text-white">
          {/* Main Content */}
          <div className="mb-12">
            <h2 className="text-4xl xl:text-5xl font-bold mb-6 leading-tight">
              La GMAO qui transforme<br />
              <span className="text-blue-300">votre maintenance</span>
            </h2>
            <p className="text-lg text-white/70 leading-relaxed">
              Rejoignez les 350+ entreprises en France et en Afrique qui ont choisi MAINTEX pour optimiser leur maintenance industrielle.
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-6 mb-12">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/20">
              <div className="text-3xl font-bold mb-1">350+</div>
              <div className="text-sm text-white/60">Clients</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/20">
              <div className="text-3xl font-bold mb-1">-30%</div>
              <div className="text-sm text-white/60">Temps d&apos;arrêt</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/20">
              <div className="text-3xl font-bold mb-1">25</div>
              <div className="text-sm text-white/60">Pays</div>
            </div>
          </div>

          {/* Features */}
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                <Shield className="w-5 h-5" />
              </div>
              <span className="text-white/80">Données hébergées en France</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                <Clock className="w-5 h-5" />
              </div>
              <span className="text-white/80">Support réactif 24/7</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                <Users className="w-5 h-5" />
              </div>
              <span className="text-white/80">Formation incluse</span>
            </div>
          </div>

          {/* Trust Badge */}
          <div className="mt-12 pt-8 border-t border-white/20">
            <div className="flex items-center gap-3">
              <img
                src="/upload/logo-bbc.png"
                alt="BBC & Partners"
                className="h-12 brightness-0 invert opacity-80"
              />
              <div>
                <div className="text-sm font-medium text-white">Développé par BBC & Partners</div>
                <div className="text-xs text-white/50">Depuis 2009</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
